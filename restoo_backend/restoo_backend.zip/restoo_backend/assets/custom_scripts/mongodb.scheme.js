 // <!-- ============================================================+
 // File name   : mongodb.scheme.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Mongo DB Scheme 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 


 /** =====================================================
  *   S C H E M E S       O F     C O L L E C T I O N S 
  * 
  * _____________________________________________________
  * Collection :::  users_collection
  
 * {
  *   _id: Object(xx)
  *   cuid: NUMBER       [ Custom Unique ID  ]
  *   utype: NUMBER       [Type of account : 1:Restaurant | 2:Client  0:Not Set]
  *   uname: TEXT       [User Fullname ]
  *   umail: TEXT       [User Mail ]
    * uadress: TEXT       [User Adress ]
  *   password: TEXT    [Encrypted password] 
  *   datecreation_now: TEXT    [Date User Open Account ]
  *   codevalidate: TEXT        [Code To validate]
  *   accountvalide: number     [User Account is Valide  1:Activated  0:Not   ]
  *   utoken: String            [User  Private Token   ]
  *   restau_name:String        [Name Of Restaurant]
  *   restau_location:String    [Restau Location]
  *   plats: ARRAY              [Liste des plats  If  Restaurant ]
  *       [ {id,name, price, pcat, desc, pimg, pdatecreate}, ...   ]
  *   rorders : ARRAY     []    
  *   corders : ARRAY     []
  * }
  * * _____________________________________________________
  * Collection :::  orders
  * 
  * {
  *   _id: Object(xx)
  *    name: string,  [Name of order :  Commande 151021.RandomeVal.Datetime  ]  
  *    ref_restaurant: string, [Restaurant Ref]
  *    ref_client: string,     [Client Ref ]  
  *    date_created: number    [date]
  *    status :number          [Status of orders : Valide | Non Valide ]
  *    nb_article :number      [Number of articles ]
  *    price_total :number     [Number of articles ]
  *    articles_list :array       [ Articles list ]
  *         [ {plat_id,plat_name, nb, punit,  price_total_article}, ...   ]
  * }
  * 
  * */

 module.exports =  {
   CONNEXION_URL: 'mongodb://localhost:27017',
   DBNAME : 'restoo_db',
   COLLECTION_LIST:['users_collection', 'orders_collection'],
   COLLECTION_USERS: 'users_collection',
   COLLECTION_ORDERS: 'orders_collection',
 }