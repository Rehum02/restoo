 // <!-- ============================================================+
 // File name   : global.func.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Contain Global Functions Server Side 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 
const log4js = require("log4js");
const cryptoJS = require('crypto-js');
const APP_CONSTANTS = require("./app.const");


const htmlEntities = [ 
  {regex:'&',entity:'&amp;'},
  {regex:'>',entity:'&gt;'},
  {regex:'<',entity:'&lt;'} 
];
log4js.configure({
  appenders: { cheese: { type: "file", filename: "_Restoo_log.log", maxLogSize: 10485760, backups: 15, compress:true } },
  categories: { default: { appenders: ["cheese"], level: "debug" } },
  disableClustering:true
});

/**  ----------------------- function list ----------------  */
const GLOBAL_FUNC = {
 
  /** @f_date_toappdateformat  Transform date to app date format  */
  f_date_toappdateformat:function (dat){
    var d = new Date(dat);
    var day = d.getUTCDate();
        day = day < 10 ? '0' + day : day;
    var month = (d.getUTCMonth() + 1);
        month = month < 10 ? '0' + month : month;
    var year = d.getUTCFullYear();
    var h = (d.getUTCHours());
        h = h < 10 ? '0' + h : h;
        h = h + 'h';
    var m = (d.getUTCMinutes());
        m = m < 10 ? '0' + m : m;
        m =  m + 'min';
    var t = day + ', ' + month + '-' + year + ' ' + h + '' + m;

    return t;
  },

  /** @f_avg  Compute Avg of array @param arr Array to compute  */
  f_avg: function (arr){  
    if(!arr.length) { throw new Error('No Array'); }

    var arr_sum = 0; 
    for (var i = 0; i < arr.length; i++) {
      arr_sum += arr[i]
    }
    return (arr_sum/arr.length);
  },

  /** @short_sentence Shorten a sentence   @param {*} s Sentence @param {*} limit Limit  */
  short_sentence: function(s, limit){  return  (s.length > limit) ? s.slice(0, limit) + ' ... ' : s;},

  /** @build_key_code Build Key Code of id  @param {*} id ID */
  build_key_code: function(id) { return (id).toString().length +'_' + id; },
  /** 
   * @getdate Get date in differents formats YYYY:MM:DD HH:MM:SS
   * @param {*} f date ouput format (YYYY-MM-DD HH:MM:SS)
   * @param {*}  dt Date Now
  */
  getdate: function(f, dt=null) {
    var  d = dt?dt: new Date();
    var dy = d.getFullYear();
    var dm = ( (d.getMonth()+1) < 10 ) ?    '0' + (d.getMonth()+1)    : d.getMonth()+1;
    var dD =  (d.getDate() < 10 ) ?   '0' + d.getDate()   : d.getDate();
    var dh = d.getHours();  
    var dmin = d.getMinutes();  
    var dsec = d.getSeconds();

    var fd = '';
    switch (f) {
      case 'YYYY-MM-DD HH:MM:SS':
        fd = dy + '-' +  dm + '-' +  dD + ' ' + dh + ':' + dmin + ':' + dsec;
        
        break;
    
      default:
        break;
    }
    
    return fd;
  },

  /**
   * @write_log Write Log in a file 
   * @param element_to_stringigy Object to Stringfy  ::  Error || AnyObject
   * @param channel Channel Description 
   * @param log_nivel Log Nivel { all, debug, info,  warn, error, fatal, off, trace  }
   * @param log_message Msg to log 
  */
 write_log: function(element_to_stringigy, channel, log_nivel, log_message){
    var error_description  =  JSON.stringify(element_to_stringigy);
    var logger = log4js.getLogger(channel);
    logger[log_nivel]('--- ' +  log_message + ' ' + error_description   + ' --- ');
 },

 /** * @htmlentities  Convert Html entities * @param {*} s string */
 htmlentities: function (s){
  var reg; 
  for (v in htmlEntities) {
    reg = new RegExp(htmlEntities[v].regex, 'g');
    s = s.replace(reg, htmlEntities[v].entity);
  }
  return s;
 },
 /** * @html_entities_decode  Reverse Html entities converted  * @param {*} s string */
 html_entities_decode: function (s){
  var reg; 
  for (v in htmlEntities) {
    reg = new RegExp(htmlEntities[v].entity, 'g');
    s = s.replace(reg, htmlEntities[v].regex);
  }
  return s;
 },
 /** * @create_user_key  Create User Key  * @param {*} ui string UserID * @param {*} type string User Type*/
  create_user_key: function (ui, type){
    var random_number_list = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    var random_chosen = Math.floor( Math.random() * (random_number_list.length - 1) );
    var random_letter_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'f', 'g', 'z', 'y', 'x'];
    var random_letter = Math.floor( Math.random() * (random_letter_list.length - 1) );
    var real_key =  ui + '.' + type  + '.' + ( Date.now() );
        real_key =  Buffer.from(real_key).toString('base64');    // NodeJS: !btoa();  // const atob = (data) => Buffer.from(data, 'base64').toString('ascii');
    var u_key =  random_letter_list[ random_letter ] + '' + random_number_list[ random_chosen ]  + '' + real_key + '';    // RandomNumber + ID + . + Type + . + Date.now 

    return u_key;
  },

  /**
   * @f_aes_encrypt Cryptage AES
   * @param {*} data  data to encrypt
   * @param {*} rf Return Format 'B64'|'HEX'
   * @param {*}  key   Key 
   * @returns 
   */
  f_aes_encrypt: function( data, rf, key){
    var b64 =  cryptoJS.AES.encrypt(data,  key).toString();
    var eHex;
    switch (rf) {
      case 'B64':
        break;
      case 'HEX':
        var e64 = cryptoJS.enc.Base64.parse(b64);
        eHex = e64.toString( cryptoJS.enc.Hex);
        break;
    
      default:break;
    }
    return eHex;
  },

  /**
   * @f_aes_decrypt DecCryptage AES
   * @param {*} data  data to decrypt
   * @param {*} rf  Return Format 'PLAINTEXT'
   * @returns 
   */
  f_aes_decrypt: function(data,  rf){
    var reb64 = cryptoJS.enc.Hex.parse(data);
    var bytes = reb64.toString( cryptoJS.enc.Base64);
    var decrypt;

    switch (rf) {
      case 'PLAINTEXT':
        decrypt = cryptoJS.AES.decrypt(bytes, APP_CONSTANTS.CONST_PRODUCT_C_KEY_BACKEND);
        var plain = decrypt.toString(cryptoJS.enc.Utf8);
        return plain;
        break;
    
      default:break;
    }
  }

}

module.exports = GLOBAL_FUNC;

