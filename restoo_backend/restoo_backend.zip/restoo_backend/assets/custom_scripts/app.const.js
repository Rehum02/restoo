 // <!-- ============================================================+
 // File name   : app.const.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Contain Project Constant : Server Side 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 

module.exports = {
   /** ------------------- PRODUCT DATA  : APP CONFIG ------------------- */
   _PRODUCTION: 'PROD',
   _DEVELOPPMENT: 'DEV',

   CONST_INDEX_PROTOCOLE : 'https://',         
   CONST_INDEX_PROTOCOLE : 'https://',         
   CONST_FRONTEND_PATH : 'https://restoo.nsiyo.com',
   CONST_BACKEND_PATH : 'https://be.restoo.nsiyo.com/be/',

   CONST_STATIC_FILES_DIR: 'assets/files',
   CONST_BACKEND_UPLOADSERVER_FOLDER:  'https://be.restoo.nsiyo.com/upldser/',

   CONST_SERVER_PORT : 8000,   
   CONST_SERVER_HOSTNAME : 'localhost',   
   CONST_SERVER_LOCALHOST : 'http://localhost:8000',      // DEV :   |   PRODUCTION::  CONST_INDEX_ROOT

   /** ------------------- APP CONFIG ------------------- */
   CONST_PRODUCT_NAME : "Restoo",
   CONST_PRODUCT_SUPPORT_EMAIL : "support@restoo.com",
   
   CONST_PRODUCT_ID : 1,
   CONST_PRODUCT_VERSION_INIT : '1.0.0',
   CONST_PRODUCT_VERSION_CURRENT : '1.0.0',
   CONST_PRODUCT_VERSION_SHORT : '1.0.0',

   CONST_PRODUCT_PUBLIC_TOKEN:"60+GAldjkqlmh563°+*HJGGK21U7BX!.:MIK&MI#BRstoHGo2021_@K!",
   CONST_PRODUCT_C_KEY_BACKEND:  "RE_MIK&MI#BRstoB2021_@K!",    // Encrypt things for backend[16]  Ex Key // 16 for 128  | 32 for 256 |  24 for 192 
   CONST_PRODUCT_C_KEY_FRONTEND:  "RE_MIK&MI#BRstoo2021_@K!",   // FrontEnd Public Key 
        
   CONST_AVOID_CHARACTERS_SQL_LIKE : /%|\.|\}|\{|\(|\)|\^|\[|\]|\$/g,
   CONST_LINK_FORMAT : /((ftps?|https?):\/\/[^\s]+)/,
   CONST_IMAGE_BASE64: /^data:image\/[^;]+;base64,/,
   CONST_APP_LANGUAGE : 'fr',   // Default Lang 
    
   CONST_BASE_FETCH_LIMIT : 7,
   CONST_BASE_FETCH_LIMIT_PUBLIC_LIST : 12,
   CONST_BASE_SENTENCE_NAME_MAX : 30,

   CONST_PRODUCT_VALIDECODE_OPTION:{ SIGNUP_VALIDE:1, PASSRESET_VALIDE:2},
   CONST_OPERATION_LOGIN:{ _email:1,_password:2  },

   CONST_PRODUCT_APP_ROLE_LIST:{ RESTAURANT :'1', CLIENT:'2'},
   CONST_PRODUCT_ORDERS_STATUS:{ VALIDE:1, NON_VALIDE: 0},
   CONST_PLATS_CATEGORIES_REVERSED:
   {
        pl01at: 'Plats africains',
        pl02bt: 'Plats européens',
        pl03ct: 'Plats asiatiques',
        pl04dt: 'Plats americains',
   },

   CONST_FRONTEND_PAGE_URL : { },
   CONST_BACKEND_ENDPOINT_LIST:
   {
       // AUTHENTIFICATION 
       sign_up:'/sign_up',
       valide_code:'/valide_code',  // (SignUp + PassReset  )
       sign_in:'/sign_in',
       passreset_init:'/passreset_init',

       // ACCOUNT 
       config_init_set:'/config_init_set',
       myfoods_set:'/myfoods_set',
       myfoods_list:'/myfoods_list',
       
       order_set:'/order_set',
       orders_list:'/orders_list',
       orders_confirm:'/orders_confirm',

       mydata_get:'/mydata_get',
       mydata_set:'/mydata_set',
       
       foods_list:'/foods_list',
   },

    /** ---------------- MAIL CONFIG   ---------------------- */
    CONST_BASE_MAIL_CHARSET: "UTF-8",  // 
    CONST_BASE_MAIL_ENCODING: "8bit",
    CONST_BASE_MAIL_SENDER: "",                     // Email d'envoi ex xxx@g.com
    CONST_BASE_MAIL_SENDER_PASS: "",                // Mot de passe
    CONST_BASE_MAIL_SMTP_HOST: "",                  // Host
    CONST_BASE_MAIL_SECURE_OPTION: "ssl",
    CONST_BASE_MAIL_PORT: 465
};

