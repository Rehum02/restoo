 // <!-- ============================================================+
 // File name   : db.connect.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Connexion to db 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 
/** ---------------REQUIRE NECESSARY FILES ---------------------------------------- */
var mysql = require('mysql');


/** --------------- PROCESSING CONNEXION ---------------------------------------- */

/** Create Connexion to db  TODO:SET  Empty These var before GIT */
var MYSQLDB_CONNEXION = mysql.createConnection({
  host: "localhost",
  user: "",       // TODO:SET SQL?
  password: '',   // TODO:SET SQL?
  database: "",   // TODO:SET SQL ?
  connectTimeout:30000,  
  connectionLimit: 10, 
  acquireTimeout: 30000,
});  


module.exports = MYSQLDB_CONNEXION;
