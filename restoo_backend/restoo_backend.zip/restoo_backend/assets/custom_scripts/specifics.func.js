 // <!-- ============================================================+
 // File name   : specifics.func.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Handle Some Specifics and repetitive functions 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 
 /**  ---------------  Get some data  ------------------------  */
const APP_CONSTANTS = require("./app.const");
const DB_CONNEXION =  require('./db.sql.connect');
const GLOBAL_FUNC = require('./global.func');
const CONST_LOG4JS_CHANNEL = require('./log4js.channels');


/**  ----------------------- function list ----------------  */
const SPECIFIC_FUNCTION = {
}

module.exports = SPECIFIC_FUNCTION;

