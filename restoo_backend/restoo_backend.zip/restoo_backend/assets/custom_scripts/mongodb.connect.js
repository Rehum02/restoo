 // <!-- ============================================================+
 // File name   : mongodb.connect.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Connexion to Mongo db 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 
/** ---------------REQUIRE NECESSARY FILES ---------------------------------------- */
const  { MongoClient } = require('mongodb');
var APP_CONSTANTS = require("./app.const"); 
const mongodbScheme = require("./mongodb.scheme");

/** --------------- PROCESSING  ---------------------------------------- */
var mongo_client = new MongoClient(mongodbScheme.CONNEXION_URL);

module.exports = {
  /** @MONGODB_CONNECT Connect to MongoDB */
  async MONGODB_CONNECT() {
    await mongo_client.connect();

    // Create Database
    console.log('Connected successfully to server');
    const db = mongo_client.db(mongodbScheme.DBNAME);
    
    // Create All Collections 
    for (let i = 0; i <  mongodbScheme.COLLECTION_LIST.length; i++) {
      db.collection(mongodbScheme.COLLECTION_LIST[i]);
    }

    return db;
  }
}
