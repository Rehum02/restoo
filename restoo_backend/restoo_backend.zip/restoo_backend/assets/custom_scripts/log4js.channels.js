 // <!-- ============================================================+
 // File name   : log4js.channels.js
 // Begin       : 06.10.21
 // Last Update : 06.10.21
 //  
 // Description : Channels 
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 
  
 /** Log4js Channels  */
const CONST_LOG4JS_CHANNEL = {
    BACKEND_DATABASE_OPERATION_ERROR: 'BACKEND_DATABASE_OPERATION_ERROR',
    BACKEND_DATABASE_CONNEXION_ERROR: 'BACKEND_DATABASE_CONNEXION_ERROR',
    BACKEND_DOWLOAD_FILE_ERROR: 'BACKEND_DOWLOAD_FILE_ERROR',
    BACKEND_DELETE_FILE: 'BACKEND_DELETE_FILE',
    
    UNEXPECTED_ERROR: 'UNEXPECTED_ERROR',
    
    WRITE_FILE_ERROR: 'WRITE_FILE_ERROR',
    READ_FILE_ERROR: 'READ_FILE_ERROR',
    
    BACKEND_AUTH: 'BACKEND_AUTH',
    BACKEND_UDATA: 'BACKEND_UDATA',
    
    SIGN_UP: 'SIGN_UP',
    CONFIRM_CODE: 'CONFIRM_CODE',
    SIGN_IN: 'SIGN_IN',
    PASSRESET_IN: 'PASSRESET_IN',
    SET_PROFILE: 'SET_PROFILE',
    
    FOOD_SAVE: 'FOOD_SAVE',
    FOOD_LIST_ACCOUNT: 'FOOD_LIST_ACCOUNT',
    HOMEPAGE_FOODLIST: 'HOMEPAGE_FOODLIST',
    
    ORDER_MAKE: 'ORDER_MAKE',
    ORDERS_LIST: 'ORDERS_LIST',
    ORDERS_CONFIRM: 'ORDERS_CONFIRM',
    
    MYDATA_GET: 'MYDATA_GET',
    MYDATA_SET: 'MYDATA_SET',

    BACKEND_OPERATION_LOG: 'BACKEND_OPERATION_LOG',
};


module.exports = CONST_LOG4JS_CHANNEL;