 // <!-- ============================================================+
 // File name   : mailer.func.js
 // Begin       : 06.10.21
 // Last Update : 07.10.21
 //  
 // Description : Send mail via NodeJS
 //  
 // Project     :  Restoo  
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 //  
 // Contributors  :
 //                 Miché KOKORA 
 // 
 // (c) Copyright 2021
 // ============================================================+ --> 
 
/**  Require NodeMailer  */
var nodemailer = require("nodemailer");
var APP_CONSTANTS = require("./app.const"); 

/**
 * ** Send Mail to SomeOne   ******************************************
 * @param {Array} mail_to_array  Recipients Adress List
 * @param {Array} mail_subject_array Messages Subjects List 
 * @param {Array} mail_text_array Messages Text List 
 * @param {Array} mail_body_array  Messages Body List
 * @param {Array} mail_attachments_array  Messages Attachments List
 *  
 * @return result_all [] 
 */
var mailer_sendmail = function(mail_to_array, mail_subject_array, mail_text_array, mail_body_array, mail_attachments_array ){ 
  /** CREATE TRANSPORT  */
  var mail_transporter =  nodemailer.createTransport(
    {
      host: APP_CONSTANTS.CONST_BASE_MAIL_SMTP_HOST,
      port: APP_CONSTANTS.CONST_BASE_MAIL_PORT,
      auth: {
        user: APP_CONSTANTS.CONST_BASE_MAIL_SENDER, 
        pass: APP_CONSTANTS.CONST_BASE_MAIL_SENDER_PASS,
      },
      secure: true
    }
  );

  var mail_body, result_all = [], result_el, mail_config = {};
  for (let i = 0; i < mail_body_array.length; i++) {

    /** CONFIG MESSAGES */
    mail_config = {
        from : [  
            { name: APP_CONSTANTS.CONST_PRODUCT_NAME,  address: APP_CONSTANTS.CONST_BASE_MAIL_SENDER}
        ],  
        to: mail_to_array[i],
        cc: '',
        bcc: APP_CONSTANTS.CONST_OWNER_EMAIL_MONITORING,
        subject: mail_subject_array[i],
        text: mail_text_array[i],
        html: mail_body_array[i],
        attachments: mail_attachments_array[i],

        replyTo:  
        [
          {name: APP_CONSTANTS.CONST_PRODUCT_NAME + ' Team ' ,  address: APP_CONSTANTS.CONST_PRODUCT_SUPPORT_EMAIL}
        ],
        priority: 'normal'
    };

    /** SEND MAIL */
    mail_transporter.sendMail(mail_config, function(error, info){
      result_el =  error? 0: 1;
      result_all.push(result_el)
    });
  }
  
  return result_all;
}

/**
 * ** Get Mail Subject & Body    ****************************************** 
 * @param {string} param_option  Choose Option 
 * @param {string} param_lang Set Lang of email
 * @param {string} param_receivername  Name of recipient
 * @param {string} param_producturl Btn AZction 
 * @param {Object} param_extras  Object  of custom data for current email
 * 
 * @return mailer_component {} 
 */
var mailer_getMailBodySubject = function(param_option = "",  param_lang = ('fr'||'en'||'es'), param_receivername, param_producturl, param_extras )
{
        var mailer_component  = {SUBJECT: '', BODY: ''};
        
        /** USER SIGN UP : SEND CODE   */
        if(param_option == 'USER_SIGNUP_MAILCODE')
        {
          var body_text = {
            subject: {
              fr: " Votre code de validation  | " + APP_CONSTANTS.CONST_PRODUCT_NAME,
              en: "" + APP_CONSTANTS.CONST_PRODUCT_NAME,
            },
            hello: {
              fr: '  Salut ' + param_receivername + ', ',
              en: '',
            },

            intro: {
              fr: " Vous avez crée un compte " +  APP_CONSTANTS.CONST_PRODUCT_NAME + '. Ci-dessous vos codes. (Changez votre mot de passe par defaut une fois connecté) ',
              en: "",
            },
            carac: {
              code_validate: {fr:'Code de validation', en:''},
              password: {fr:'Mot de passe', en:''},
            },
            letgo: { fr: "",en: "",},
            confirm_btn: { fr: '', en: ''},

            cordial: {
              fr: " Merci d'être " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordialement. " ,
              en: " Thanks to be  " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordially. " ,
            },
          };

          /** Building Body  */
          mailer_component.SUBJECT = body_text.subject[param_lang];
          mailer_component.BODY = 
              '<!DOCTYPE html>'+
              '<html lang="fr">'+
                '<head>'+
                  '<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />'+
                  '<meta name="viewport" content="width=device-width, initial-scale=1.0">'+
                '</head>'+
                '<body>'+
                '<table style="height:100%; width:100%; word-break: break-word; background-color : #f0ecec !important;font-family:\'Segoe UI\', \'Calibri Light\', Roboto,\'Helvetica Neue\',sans-serif; margin:0;padding:0; font-size:1em; margin-bottom: 1rem; color: #212529; border-collapse: collapse; display: block;">'+
                    '<thead style="display:none"></thead>'+
                    '<tbody>'+
                      '<tr>'+
                        '<td style="width:100%; height:100%; background-color: transparent">'+
                          '<table  style="margin-bottom: 1rem; color: #212529;border-collapse: collapse;width:90%;margin:auto;">'+
                            '<thead style="display:none "></thead>'+
                            '<tbody>'+
                              '<!-- HEADER COMPANY NAME   -->'+
                              '<tr style="width: 100%; min-height:90px;max-height:100px; background-color: transparent">'+
                                '<td style="width:100%; height:100%; padding-top:1em; padding-bottom:1em; text-align:center"> '+
                                  '<a href="#" style="text-decoration: none; cursor:pointer;"> ' + APP_CONSTANTS.CONST_PRODUCT_NAME + '  </a>'+
                                '</td>'+
                              '</tr>'+
                              '<!-- BODY OF EMAIL  : CHANGE ONLY THE CONTENT OF THAT SECTION  -->'+
                              '<tr style="width: 100%; min-height:200px; height:auto; background-color: white">'+
                                '<td style="width: 100%; height:100%;padding:1em;">'+
                                  '<!-- ---  START CHANGING HERE ----- -->'+
                                                                  
                                  '<div> ' + body_text.hello[param_lang] + '</div>'+
                                  '<div style="margin-top:2em"> '+
                                    body_text.intro[param_lang]  +
                                  '</div>'+
                                  '<div style="margin-top:2em; font-weight:bold;"> '+
                                      '<div> ' +  body_text.carac.code_validate[param_lang] + ' : <b>' + param_extras.CODE + ' </b> </div> '+
                                      '<div style="margin-top:1em" > ' +  body_text.carac.password[param_lang] + ' : <b>' + param_extras.PASSWORD + ' </b> </div> '+
                                  '</div>'+
                                  '<div style="margin-top:2em"> <br><br></div>'+
                                
                                  '<div style="margin-top:2em; width:100%; height:4em; text-align:center">'+
                                    '<a style="text-decoration:none !important;"  href="' + param_producturl + '"> '+
                                      '<span style="background-color: #007bff !important;color: white !important;border-radius: 5px !important;text-align:center!important;padding: 10px!important;">'+
                                        body_text.confirm_btn[param_lang]  +
                                      '</span>' +
                                    '</a>' +
                                  '</div>' +

                                  '<div style="margin-top:2em; font-style: italic">  ' + body_text.cordial[param_lang] + ' </div> '+
                                  '<hr style="margin-top:2em; margin-left:auto; margin-right:auto; width:75%">'+
                                '</td>'+
                              '</tr>'+

                              '<!-- FOOTER OF  EMAIL  -->'+
                              '<tr style="width: 100%; min-height:150px; height:auto; background-color: transparent">'+
                                '<td style="width: 100%; height:100%;padding:1em; color: #6c757d !important;">'+
                                    '<div style="width:100%; height:auto; text-align: center"> <h4> '+ APP_CONSTANTS.CONST_PRODUCT_NAME + ' </h4> </div>'+
                                '</td>'+
                              '</tr>'+
                            '</tbody>'+
                          '</table>'+
                        '</td>'+
                      '</tr>'+
                    '</tbody>'+
                    '</table>'+
                  '</body>'+
                  '</html>';

          return mailer_component;
        }


        /** USER INIT PASSRESET  : SEND CODE   */
        if(param_option == 'USER_PASSRESET_INIT')
        {
          var body_text = {
            subject: {
              fr: " Votre code de réinitialisation  | " + APP_CONSTANTS.CONST_PRODUCT_NAME,
              en: "" + APP_CONSTANTS.CONST_PRODUCT_NAME,
            },
            hello: {
              fr: '  Salut ' + param_receivername + ', ',
              en: '',
            },

            intro: {
              fr: " Votre code de réinitialisation ",
              en: "",
            },
            carac: {
              code_validate: {fr:'Code de validation', en:''},
            },
            letgo: { fr: "",en: "",},
            confirm_btn: { fr: '', en: ''},

            cordial: {
              fr: " Merci d'être " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordialement. " ,
              en: " Thanks to be  " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordially. " ,
            },
          };

          /** Building Body  */
          mailer_component.SUBJECT = body_text.subject[param_lang];
          mailer_component.BODY = 
              '<!DOCTYPE html>'+
              '<html lang="fr">'+
                '<head>'+
                  '<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />'+
                  '<meta name="viewport" content="width=device-width, initial-scale=1.0">'+
                '</head>'+
                '<body>'+
                '<table style="height:100%; width:100%; word-break: break-word; background-color : #f0ecec !important;font-family:\'Segoe UI\', \'Calibri Light\', Roboto,\'Helvetica Neue\',sans-serif; margin:0;padding:0; font-size:1em; margin-bottom: 1rem; color: #212529; border-collapse: collapse; display: block;">'+
                    '<thead style="display:none"></thead>'+
                    '<tbody>'+
                      '<tr>'+
                        '<td style="width:100%; height:100%; background-color: transparent">'+
                          '<table  style="margin-bottom: 1rem; color: #212529;border-collapse: collapse;width:90%;margin:auto;">'+
                            '<thead style="display:none "></thead>'+
                            '<tbody>'+
                              '<!-- HEADER COMPANY NAME   -->'+
                              '<tr style="width: 100%; min-height:90px;max-height:100px; background-color: transparent">'+
                                '<td style="width:100%; height:100%; padding-top:1em; padding-bottom:1em; text-align:center"> '+
                                  '<a href="#" style="text-decoration: none; cursor:pointer;"> ' + APP_CONSTANTS.CONST_PRODUCT_NAME + '  </a>'+
                                '</td>'+
                              '</tr>'+
                              '<!-- BODY OF EMAIL  : CHANGE ONLY THE CONTENT OF THAT SECTION  -->'+
                              '<tr style="width: 100%; min-height:200px; height:auto; background-color: white">'+
                                '<td style="width: 100%; height:100%;padding:1em;">'+
                                  '<!-- ---  START CHANGING HERE ----- -->'+
                                                                  
                                  '<div> ' + body_text.hello[param_lang] + '</div>'+
                                  '<div style="margin-top:2em"> '+
                                    body_text.intro[param_lang]  +
                                  '</div>'+
                                  '<div style="margin-top:2em; font-weight:bold;"> '+
                                      '<div> ' +  body_text.carac.code_validate[param_lang] + ' : <b>' + param_extras.CODE + ' </b> </div> '+
                                  '</div>'+
                                  '<div style="margin-top:2em"> <br><br></div>'+
                                
                                  '<div style="margin-top:2em; width:100%; height:4em; text-align:center">'+
                                    '<a style="text-decoration:none !important;"  href="' + param_producturl + '"> '+
                                      '<span style="background-color: #007bff !important;color: white !important;border-radius: 5px !important;text-align:center!important;padding: 10px!important;">'+
                                        body_text.confirm_btn[param_lang]  +
                                      '</span>' +
                                    '</a>' +
                                  '</div>' +

                                  '<div style="margin-top:2em; font-style: italic">  ' + body_text.cordial[param_lang] + ' </div> '+
                                  '<hr style="margin-top:2em; margin-left:auto; margin-right:auto; width:75%">'+
                                '</td>'+
                              '</tr>'+

                              '<!-- FOOTER OF  EMAIL  -->'+
                              '<tr style="width: 100%; min-height:150px; height:auto; background-color: transparent">'+
                                '<td style="width: 100%; height:100%;padding:1em; color: #6c757d !important;">'+
                                    '<div style="width:100%; height:auto; text-align: center"> <h4> '+ APP_CONSTANTS.CONST_PRODUCT_NAME + ' </h4> </div>'+
                                '</td>'+
                              '</tr>'+
                            '</tbody>'+
                          '</table>'+
                        '</td>'+
                      '</tr>'+
                    '</tbody>'+
                    '</table>'+
                  '</body>'+
                  '</html>';

          return mailer_component;
        }


        /** CLIENT MAKE ORDER : NOTIFY RESTAURANT   */
        if(param_option == 'ORDER_MAKE')
        {
          var body_text = {
            subject: {
              fr:  param_extras ['name'] + " | " + APP_CONSTANTS.CONST_PRODUCT_NAME,
              en: "" + APP_CONSTANTS.CONST_PRODUCT_NAME,
            },
            hello: {
              fr: param_receivername + ', ',
              en: '',
            },

            intro: {
              fr: " Vous avez une nouvelle commande. Le resumé est ci-dessous. Validez la commande sur la plateforme.  ",
              en: "",
            },
            carac: {
              reference: {fr:'Reference', en:''},
              nb_article: {fr:'Nombre d\'articles', en:''},
              price_total: {fr:'Prix total', en:''},
              date_order: {fr:'Date ', en:''},
            },
            letgo: { fr: "",en: "",},
            confirm_btn: { fr: '', en: ''},

            cordial: {
              fr: " Merci d'être " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordialement. " ,
              en: " Thanks to be  " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordially. " ,
            },
          };

          /** Building Body  */
          mailer_component.SUBJECT = body_text.subject[param_lang];
          mailer_component.BODY = 
              '<!DOCTYPE html>'+
              '<html lang="fr">'+
                '<head>'+
                  '<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />'+
                  '<meta name="viewport" content="width=device-width, initial-scale=1.0">'+
                '</head>'+
                '<body>'+
                '<table style="height:100%; width:100%; word-break: break-word; background-color : #f0ecec !important;font-family:\'Segoe UI\', \'Calibri Light\', Roboto,\'Helvetica Neue\',sans-serif; margin:0;padding:0; font-size:1em; margin-bottom: 1rem; color: #212529; border-collapse: collapse; display: block;">'+
                    '<thead style="display:none"></thead>'+
                    '<tbody>'+
                      '<tr>'+
                        '<td style="width:100%; height:100%; background-color: transparent">'+
                          '<table  style="margin-bottom: 1rem; color: #212529;border-collapse: collapse;width:90%;margin:auto;">'+
                            '<thead style="display:none "></thead>'+
                            '<tbody>'+
                              '<!-- HEADER COMPANY NAME   -->'+
                              '<tr style="width: 100%; min-height:90px;max-height:100px; background-color: transparent">'+
                                '<td style="width:100%; height:100%; padding-top:1em; padding-bottom:1em; text-align:center"> '+
                                  '<a href="#" style="text-decoration: none; cursor:pointer;"> ' + APP_CONSTANTS.CONST_PRODUCT_NAME + '  </a>'+
                                '</td>'+
                              '</tr>'+
                              '<!-- BODY OF EMAIL  : CHANGE ONLY THE CONTENT OF THAT SECTION  -->'+
                              '<tr style="width: 100%; min-height:200px; height:auto; background-color: white">'+
                                '<td style="width: 100%; height:100%;padding:1em;">'+
                                  '<!-- ---  START CHANGING HERE ----- -->'+
                                                                  
                                  '<div> ' + body_text.hello[param_lang] + '</div>'+
                                  '<div style="margin-top:2em"> '+
                                    body_text.intro[param_lang]  +
                                  '</div>'+
                                  '<div style="margin-top:2em; font-weight:bold;"> '+
                                      '<div> ' +  body_text.carac.reference[param_lang] + ': <b>' + param_extras.name + ' </b> </div> '+
                                      '<div> ' +  body_text.carac.nb_article[param_lang] + ': <b>' + param_extras.nb_article + ' </b> </div> '+
                                      '<div> ' +  body_text.carac.price_total[param_lang] + ': <b>' + param_extras.price_total + ' F CFA  </b> </div> '+
                                      '<div> ' +  body_text.carac.date_order[param_lang] + ': <b>' + param_extras.date_ + ' </b> </div> '+
                                  '</div>'+
                                  '<div style="margin-top:2em"> <br><br></div>'+
                                
                                  '<div style="margin-top:2em; width:100%; height:4em; text-align:center"></div>' +

                                  '<div style="margin-top:2em; font-style: italic">  ' + body_text.cordial[param_lang] + ' </div> '+
                                  '<hr style="margin-top:2em; margin-left:auto; margin-right:auto; width:75%">'+
                                '</td>'+
                              '</tr>'+

                              '<!-- FOOTER OF  EMAIL  -->'+
                              '<tr style="width: 100%; min-height:150px; height:auto; background-color: transparent">'+
                                '<td style="width: 100%; height:100%;padding:1em; color: #6c757d !important;">'+
                                    '<div style="width:100%; height:auto; text-align: center"> <h4> '+ APP_CONSTANTS.CONST_PRODUCT_NAME + ' </h4> </div>'+
                                '</td>'+
                              '</tr>'+
                            '</tbody>'+
                          '</table>'+
                        '</td>'+
                      '</tr>'+
                    '</tbody>'+
                    '</table>'+
                  '</body>'+
                  '</html>';

          return mailer_component;
        }

        /** RESTAURANT CONFIRM : NOTIFY CLIENT  */
        if(param_option == 'ORDER_CONFIRM')
        {
          var body_text = {
            subject: {
              fr: "Validé | " +  param_extras ['name'] + " | " + APP_CONSTANTS.CONST_PRODUCT_NAME,
              en: "" + APP_CONSTANTS.CONST_PRODUCT_NAME,
            },
            hello: {
              fr: param_receivername + ', ',
              en: '',
            },

            intro: {
              fr: " Votre commande a été validée. Vous recevrez les articles bientot. Rappel de votre commande:  ",
              en: "",
            },
            carac: {
              reference: {fr:'Reference', en:''},
              nb_article: {fr:'Nombre d\'articles', en:''},
              price_total: {fr:'Prix total', en:''},
              date_order: {fr:'Date ', en:''},
            },
            letgo: { fr: "",en: "",},
            confirm_btn: { fr: '', en: ''},

            cordial: {
              fr: " Merci d'être " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordialement. " ,
              en: " Thanks to be  " + APP_CONSTANTS.CONST_PRODUCT_NAME + ".  <br> Cordially. " ,
            },
          };

          /** Building Body  */
          mailer_component.SUBJECT = body_text.subject[param_lang];
          mailer_component.BODY = 
              '<!DOCTYPE html>'+
              '<html lang="fr">'+
                '<head>'+
                  '<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />'+
                  '<meta name="viewport" content="width=device-width, initial-scale=1.0">'+
                '</head>'+
                '<body>'+
                '<table style="height:100%; width:100%; word-break: break-word; background-color : #f0ecec !important;font-family:\'Segoe UI\', \'Calibri Light\', Roboto,\'Helvetica Neue\',sans-serif; margin:0;padding:0; font-size:1em; margin-bottom: 1rem; color: #212529; border-collapse: collapse; display: block;">'+
                    '<thead style="display:none"></thead>'+
                    '<tbody>'+
                      '<tr>'+
                        '<td style="width:100%; height:100%; background-color: transparent">'+
                          '<table  style="margin-bottom: 1rem; color: #212529;border-collapse: collapse;width:90%;margin:auto;">'+
                            '<thead style="display:none "></thead>'+
                            '<tbody>'+
                              '<!-- HEADER COMPANY NAME   -->'+
                              '<tr style="width: 100%; min-height:90px;max-height:100px; background-color: transparent">'+
                                '<td style="width:100%; height:100%; padding-top:1em; padding-bottom:1em; text-align:center"> '+
                                  '<a href="#" style="text-decoration: none; cursor:pointer;"> ' + APP_CONSTANTS.CONST_PRODUCT_NAME + '  </a>'+
                                '</td>'+
                              '</tr>'+
                              '<!-- BODY OF EMAIL  : CHANGE ONLY THE CONTENT OF THAT SECTION  -->'+
                              '<tr style="width: 100%; min-height:200px; height:auto; background-color: white">'+
                                '<td style="width: 100%; height:100%;padding:1em;">'+
                                  '<!-- ---  START CHANGING HERE ----- -->'+
                                                                  
                                  '<div> ' + body_text.hello[param_lang] + '</div>'+
                                  '<div style="margin-top:2em"> '+
                                    body_text.intro[param_lang]  +
                                  '</div>'+
                                  '<div style="margin-top:2em; font-weight:bold;"> '+
                                      '<div> ' +  body_text.carac.reference[param_lang] + ': <b>' + param_extras.name + ' </b> </div> '+
                                      '<div> ' +  body_text.carac.nb_article[param_lang] + ': <b>' + param_extras.nb_article + ' </b> </div> '+
                                      '<div> ' +  body_text.carac.price_total[param_lang] + ': <b>' + param_extras.price_total + ' F CFA  </b> </div> '+
                                  '</div>'+
                                  '<div style="margin-top:2em"> <br><br></div>'+
                                
                                  '<div style="margin-top:2em; width:100%; height:4em; text-align:center"></div>' +

                                  '<div style="margin-top:2em; font-style: italic">  ' + body_text.cordial[param_lang] + ' </div> '+
                                  '<hr style="margin-top:2em; margin-left:auto; margin-right:auto; width:75%">'+
                                '</td>'+
                              '</tr>'+

                              '<!-- FOOTER OF  EMAIL  -->'+
                              '<tr style="width: 100%; min-height:150px; height:auto; background-color: transparent">'+
                                '<td style="width: 100%; height:100%;padding:1em; color: #6c757d !important;">'+
                                    '<div style="width:100%; height:auto; text-align: center"> <h4> '+ APP_CONSTANTS.CONST_PRODUCT_NAME + ' </h4> </div>'+
                                '</td>'+
                              '</tr>'+
                            '</tbody>'+
                          '</table>'+
                        '</td>'+
                      '</tr>'+
                    '</tbody>'+
                    '</table>'+
                  '</body>'+
                  '</html>';

          return mailer_component;
        }
       
    
        /** ------------------- OTHERS ....  ------------------- */
}

const MAILER_FUNC = {
  sendEmail: mailer_sendmail,
  getMailBodySubjet: mailer_getMailBodySubject
};


module.exports = MAILER_FUNC;