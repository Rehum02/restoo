// <!-- =========================  Hooo ===================================+
 // Restoo  :01   == > 1.0.0
 // Description : Restoo Backend
 // 
 // https://be.restoo.nsiyo.com/be/
 // Designed By :  Miché KOKORA 
 // For         :  GS2E
 // Support     :  rehum@live.fr 
     
 // (c) Copyright Eph & Mi  2021
 // ============================================================+ -->
 
 
/** ---------------REQUIRE NECESSARY FILES ---------------------------------------- */
var express = require('express');
var http = require('http');
var cors = require('cors'); 
var CryptoJS = require('crypto-js');
const cron = require('node-cron');       // const CronJob = require('cron').CronJob;  
const fetch = require('node-fetch');
var fs = require('fs');
const path = require("path");

const APP_CONSTANTS = require("./assets/custom_scripts/app.const");
const MYSQLDB_CONNEXION   = require('./assets/custom_scripts/db.sql.connect');
const MAILER_FUNC  = require('./assets/custom_scripts/mailer.func');
const GLOBAL_FUNC  = require('./assets/custom_scripts/global.func');
const SPECIFIC_FUNCTION  = require('./assets/custom_scripts/specifics.func');
const CONST_LOG4JS_CHANNEL   = require('./assets/custom_scripts/log4js.channels');
const  MONGODB_CONNEXION = require('./assets/custom_scripts/mongodb.connect');
const  MONGODB_SCHEMES = require('./assets/custom_scripts/mongodb.scheme');
const { ObjectId } = require('bson');


/** --------------- CONFIG /  SETUP SERVER ---------------------------------------- */
const APP_ENV = APP_CONSTANTS._DEVELOPPMENT; // ('DEV'||'PROD')
const port = APP_CONSTANTS.CONST_SERVER_PORT;
const hostname = APP_CONSTANTS.CONST_SERVER_HOSTNAME;

var app = express();
var 
   appRouter = express.Router(),
   appProtectedRouter = express.Router(),
   appPublicRouter = express.Router();

var server = http.createServer(app);

process.env.TZ = "Africa/Abidjan";
var app_time_config = {zone: process.env.TZ,  tz_number: new Date().getTimezoneOffset()};
app.use(cors({origin:'*'}));       
app.use( express.static( APP_CONSTANTS.CONST_STATIC_FILES_DIR)); 
app.use( express.json({limit:'50mb'}) );  // Support max data in params
app.disable('x-powered-by');

/** --------------- MONGODB    ---------------------------------------- */


/** Connecting to DB : MySQL  TODO:SET Maybe Remove this  */
switch (APP_ENV) {
   case APP_CONSTANTS._PRODUCTION :   // SQL : Because deploy Server Not Use MongoDB
      MYSQLDB_CONNEXION.connect(err1 => {
         if(err1){ GLOBAL_FUNC.write_log(err1, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_CONNEXION_ERROR, 'error',  '::PROD');}
      });
      break;

   case APP_CONSTANTS._DEVELOPPMENT:   // MONGO DB
      break;

   default:break;
}


/** -------------------- E X P R E S S     I N D E X     R O U T E S ---------------------------*/
appRouter
   .get('/', (req, res) => { 
      GLOBAL_FUNC.write_log({u_ip: req.ip, }, CONST_LOG4JS_CHANNEL.BACKEND_URL_ERROR, 'info', ' HOME_PAGE_ACCESSING ::  /  ');
      res.sendFile(__dirname + '/assets/pages/index.html');     // res.send('Oops, Page Unauthorized. It all we know'); res.end();
   });


/** -------------------- E X P R E S S     P U B L I C     R O U T E S ---------------------------*/
appPublicRouter
   .use(function (req, res, next) {  
      /** --------------- --------------- MIDDLEWARE --------------- ---------------
         * Middleware 
         * Begin                 : 06.10.2021
         * Last Update           : *
         *
         * Description           : Calls the middleware on all public route : Check Public Token
         * 
         * Contributors          :
         *                         Miché KOKORA - <rehum@live.fr>
         * 
         * Algo                  :
         *                          1- Check If Token+ Name Match
         *                          2- If Match, Go To endpoint 
         *  --------------- --------------- ---------------  --------------- ---  */
      var
         ptoken = req.body ['_ptk'],
         pname = req.body ['_pn'];
 
      var q, param_value, stateOfRequest = {isOkay:0, desc:'ERRO_AUTH </> '}, error_des; 
      if(ptoken != APP_CONSTANTS.CONST_PRODUCT_PUBLIC_TOKEN || pname != APP_CONSTANTS.CONST_PRODUCT_NAME )
      {
         res.send( stateOfRequest);return; 
      }

      next();
   }) 

   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 06.10.2021
      * Last Update           : 06.10.2021
      *
      * Description           : Sign Up
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Check data if not exist , If it Exist Stop, Otherwise Go 2
      *                          2- Save 
      *                          3- Send mail to user
   *  --------------- --------------- ---------------  --------------- ---  */
   //   .post('/sign_up', (req, res, next) => {
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.sign_up, (req, res, next) => {
         var
            uname = req.body['un'],
            umail = req.body['ue']
         ;

         var stateOfRequest = {isOkay:1, rid:0, err_code: ''};
         var q, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip }, CONST_LOG4JS_CHANNEL.SIGN_UP, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               // 1- Check data if not exist , If it Exist Stop, Otherwise Go 2
               var q = {umail: umail};
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                  if(data && data['umail'])
                  {
                     stateOfRequest.isOkay = -1;
                     res.send(stateOfRequest);return;
                  }

                  // 2 Save 
                  var code_to_validate = ( Math.random().toString().slice(2, 10) );
                  var  default_password =  ( Math.random().toString().slice(2, 10) );
                       default_password =  Buffer.from(default_password).toString('base64');
                       default_password = default_password.replace('=', '!');
                  var default_password_saved = CryptoJS.SHA256(default_password).toString(CryptoJS.enc.Hex);
                  
                  var dn = Date.now();
                  var cuid = umail  + '' + ( dn );
                      cuid = 'N' + ( Math.random().toString().slice(2, 4) ) + (Buffer.from(cuid).toString('base64'));

                  q = { cuid:cuid, utype:0, uname: uname,  umail:umail, password:default_password_saved, datecreation_now: dn,  accountvalide: 0, codevalidate: code_to_validate, plats:[], rorders:[], corders:[], utoken: '',uadress:'', restau_name:'', restau_location: ''  };

                  RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).insertOne(q).then((data_2)=> {
                     if( !data_2.acknowledged)  // Log If Error 
                     {
                        error_des = '(S:R0710211036)';
                        stateOfRequest.err_code = error_des;
                        GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                        res.send(stateOfRequest);return;
                     }
                     
                     stateOfRequest.isOkay = data_2.insertedId ? 1: 0;
                     stateOfRequest.rid = data_2.insertedId;
                     res.send(stateOfRequest);

                     // 3 - Send Email 
                     var param_extras = {  CODE:code_to_validate,   PASSWORD:default_password };
                     var mbs =  MAILER_FUNC.getMailBodySubjet('USER_SIGNUP_MAILCODE', APP_CONSTANTS.CONST_APP_LANGUAGE, uname, '', param_extras );
                     var email_components = { adress:[umail], subject:[mbs.SUBJECT], body:[mbs.BODY]};
                     var mess_sentresult = MAILER_FUNC.sendEmail( email_components.adress, email_components.subject, [], email_components.body, []);
                  });
               });
            });
         } else {  //  TODO:SET SQL 

         }
   })
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 07.10.2021
      * Last Update           : 07.10.2021
      *
      * Description           : Valida code ( PassReset + Sign Up Code )
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Check If Code Exist In DB 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.valide_code , (req, res, next) => {
         var
            umail = req.body['ui'],  // User Email 
            code_to_validate = req.body['uc'],
            o_option = req.body['o']
         ;

         var stateOfRequest = {isOkay:0, o:o_option, setup:0,ut: 0,ciphertext:'', ds:0, err_code:''  };
         var q, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip }, CONST_LOG4JS_CHANNEL.CONFIRM_CODE, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               // * 1- Check If Code Exist In DB 
               q =  [ {umail: umail}, {codevalidate: code_to_validate} ];
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne({ $and:q}).then((data)=>{
                  if(data && data['umail'])
                  {
                     stateOfRequest.isOkay = 1;
                  }

                  if(o_option == APP_CONSTANTS.CONST_PRODUCT_VALIDECODE_OPTION.SIGNUP_VALIDE)
                  {
                     res.send(stateOfRequest);
                  }
                  if(o_option == APP_CONSTANTS.CONST_PRODUCT_VALIDECODE_OPTION.PASSRESET_VALIDE)
                  {
                     // 2-1 - Build LoggedIn Credeentials, Save Token & Send Result To User 
                     var utoken  =  (Date.now()) + ''+ (Math.random().toString().slice(2)) + '' + (Date.now());
                     var ds = Date.now();
                     var utype =  data.utype;
                     var udata = 
                     {
                        ui: data._id,       
                        cui: data.cuid,       
                        ut: utype, 
                        un: data.uname, 
                        utk: utoken,                  
                           
                        c_cs: data.accountvalide,   // 1st Setup Done 
                        _st: ds
                     };
                     q =  {umail: umail};
                     var nd = {utoken: utoken};
   
                     RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                        if( !data_ur.acknowledged)  // Log If Error 
                        {
                           error_des = '(S:R0710211120)';
                           stateOfRequest.err_code = error_des;
                           GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                           res.send(stateOfRequest);return;
                        }
   
                        var d = JSON.stringify(udata);
                        var ciphertext =  GLOBAL_FUNC.f_aes_encrypt(d, 'HEX', APP_CONSTANTS.CONST_PRODUCT_C_KEY_FRONTEND);
                        stateOfRequest = {
                           o : o_option,
                           isOkay: 1, 
                           setup : data.accountvalide,
   
                           ciphertext:ciphertext,
                           ds: ds,
                           ut: utype
                        };
                        res.send(stateOfRequest);return;
                     });
                  }

                  // 2 - If Correct, Clean Code 
                  if(stateOfRequest.isOkay == 1)
                  {
                     q =  {umail: umail};
                     var nd =  {codevalidate: ''} 
                     RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                        if( !data_ur.acknowledged || !data_ur.modifiedCount)  // Log If Error 
                        {
                           error_des = '(S:R0710210857)';
                           GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                        }
                     });
                  }
               });
            });
         } else {  //  TODO:SET SQL 

         }
   })
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 07.10.2021
      * Last Update           : 07.10.2021
      *
      * Description           : Sign In 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Step1: Check Email 
      *                          2- Step2: Check Pass 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.sign_in , (req, res, next) => {

         var
            umail = req.body['ue'],  // User Email 
            upass = req.body['up'],
            o_option = req.body['o']
         ;

         var stateOfRequest = {isOkay:0, o:o_option, setup:0,ut: 0,ciphertext:'', ds:0, err_code:''  };
         var q, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip }, CONST_LOG4JS_CHANNEL.SIGN_IN, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               // * 1- Step1: Check Email 
               if(o_option == APP_CONSTANTS.CONST_OPERATION_LOGIN._email)
               {
                  q =  {umail: umail};
                  RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                     stateOfRequest.isOkay =  (data && data['umail']) ?  1 : -1;
                     res.send(stateOfRequest);
                     return;
                  });
               }

               // * 2 - Step2: Check Pass 
               if(o_option == APP_CONSTANTS.CONST_OPERATION_LOGIN._password)
               {
                  var passw_crypted = CryptoJS.SHA256(upass).toString(CryptoJS.enc.Hex);
                  q =  [ {umail: umail}, {password: passw_crypted }];
                  RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne({$and:q}).then((data)=>{
                     stateOfRequest.isOkay =  (data && data['umail']) ?  1 : -1;
                     if(stateOfRequest.isOkay == -1)
                     {
                        res.send(stateOfRequest);
                        return;
                     }

                     // 2-1 - If Correct, Save Token & Send Result To User 
                     var utoken  =  (Date.now()) + ''+ (Math.random().toString().slice(2)) + '' + (Date.now());
                     var ds = Date.now();
                     var utype = data.utype;
                     var udata = 
                     {
                        ui: data._id,       
                        cui: data.cuid,       
                        ut: utype, 
                        un: data.uname, 
                        utk: utoken,                  
                        
                        c_cs: data.accountvalide,   // 1st Setup Done 
                        _st: ds
                     };
                     q =  {umail: umail};
                     var nd = {utoken: utoken};

                     RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                        if( !data_ur.acknowledged)  // Log If Error 
                        {
                           error_des = '(S:R0710211015)';
                           stateOfRequest.err_code = error_des;
                           GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                           res.send(stateOfRequest);return;
                        }

                        var d = JSON.stringify(udata);
                        var ciphertext =  GLOBAL_FUNC.f_aes_encrypt(d, 'HEX', APP_CONSTANTS.CONST_PRODUCT_C_KEY_FRONTEND);
                        stateOfRequest = 
                        {
                           o : o_option,
                           isOkay: 1, 
                           setup : data.accountvalide,

                           ciphertext:ciphertext,
                           ds: ds,
                           ut: utype
                        };
                        res.send(stateOfRequest);return;
                     });
                  });
               }
            });
         } else {  //  TODO:SET SQL 
  
         }
   }) 
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 07.10.2021
      * Last Update           : 07.10.2021
      *
      * Description           : PassReset Init 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Check Mail Existence , If Yes, Go 2
      *                          1- Send Email With Code for pass Reset 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.passreset_init , (req, res, next) => {

         var
            umail = req.body['ue']  // User Email 
         ;

         var stateOfRequest = {isOkay:0, err_code:''  };
         var q, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip }, CONST_LOG4JS_CHANNEL.PASSRESET_IN, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               
               // 1- Get User data + Send Email With Code for pass Reset  
               q =  {umail: umail};
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                  stateOfRequest.isOkay =  (data && data['umail']) ?  1 : -1;
                  if(stateOfRequest.isOkay == -1)
                  {
                     res.send(stateOfRequest);
                     return;
                  }
                  res.send(stateOfRequest);
                  var u_name = data.uname; 

                  // 2 - Save Code 
                  var code_to_validate = ( Math.random().toString().slice(2, 10) );
                  q =  {umail: umail};
                  var nd =  {codevalidate: code_to_validate};
                  RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                     if( !data_ur.acknowledged || !data_ur.modifiedCount)  // Log If Error 
                     {
                        error_des = '(S:R0710211243)';  
                        stateOfRequest.err_code = error_des;
                        GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                        res.send(stateOfRequest); return;
                     }

                     // 3 - Send  Mail 
                     var param_extras = {  CODE:code_to_validate };
                     var mbs =  MAILER_FUNC.getMailBodySubjet('USER_PASSRESET_INIT', APP_CONSTANTS.CONST_APP_LANGUAGE, u_name, '', param_extras );
                     var email_components = { adress:[umail], subject:[mbs.SUBJECT], body:[mbs.BODY]};
                     var mess_sentresult = MAILER_FUNC.sendEmail( email_components.adress, email_components.subject, [], email_components.body, []);
                  });

               });
            });

         } else {  //  TODO:SET SQL 

         }
   }) 
      
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 16.10.2021
      * Last Update           : 16.10.2021
      *
      * Description           : List Of Foods : Public 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Get List Of Foods from all restaurant
      * 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.foods_list , (req, res, next) => {
         var 
            pname = req.body['pn']
         ;

         var stateOfRequest = {isOkay:0, payload:[],restau_list:[],  err_code:''  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip}, CONST_LOG4JS_CHANNEL.HOMEPAGE_FOODLIST, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               q = { utype: APP_CONSTANTS.CONST_PRODUCT_APP_ROLE_LIST.RESTAURANT};
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).find(q).toArray().then((data)=>{
                  
                  var d = []; d = data;
                  var plats = [],  restau_name = '', restau_id = '', restau_mail='', p_name = "", p_img="", shorten_desc, p_cat = "";
                  var desc_limit = 45, name_limit = 30;
                  var d_back = [], restaurant_names = [];

                  for (var i = 0; i < d.length; i++) {
                     plats = d[i]['plats'];
                     restau_id = d[i]['_id'];
                     restau_mail = (Math.random().toString().slice(2,5)) + Buffer.from(d[i]['umail']).toString('base64');
        
                     restau_name = d[i]['restau_name'] ? d[i]['restau_name'] : d[i]['uname'];
                     restaurant_names.push({id:restau_id, rn: restau_name});
                     restau_name =  GLOBAL_FUNC.short_sentence(restau_name,  name_limit);

                     plats.map((v, i)=>{
                        // 1 - Transform Image : Set Correct Path 
                        p_img = APP_CONSTANTS.CONST_BACKEND_UPLOADSERVER_FOLDER + '' + v.pimg;

                        // 3 - Shorten Desc 
                        shorten_desc =  GLOBAL_FUNC.short_sentence( v.desc, desc_limit);
                        
                        // 4 - Shorten Plat Name  
                        p_name =  GLOBAL_FUNC.short_sentence( v.name, name_limit);

                        d_back.push(
                           {
                              id: v.id,
                              pimg:p_img,
                              name:p_name,
                              rname:restau_name,
                              price:v.price,
                              pcat:v.pcat,
                              desc_short: shorten_desc,
                              desc: v.desc,

                              restau_id : restau_id,
                              restau_m: restau_mail
                           }
                        );
                     });
                  }

                  stateOfRequest.isOkay = 1;
                  stateOfRequest.payload = d_back;
                  stateOfRequest.restau_list = restaurant_names;
                  res.send(stateOfRequest);return;
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })

   ;



   /** -------------------- E X P R E S S    A C C O U N T     R O U T E S  ---------------------------*/
appProtectedRouter
   .use(function (req, res, next) {  
      /** --------------- --------------- MIDDLEWARE --------------- ---------------
         * Middleware 
         * Begin                 : 07.10.2021
         * Last Update           : *
         *
         * Description           : Calls the middleware on all Users Account routes :  When Logged In
         * 
         * Contributors          :
         *                         Miché KOKORA - <rehum@live.fr>
         * 
         * Algo                  :
         *                          1- Check Public Token+ Name Match
         *                          2- If Match, Go To 3
         *                          3- Check User Public Token
         *                          4- If Match , Go Endpoint 
         * 
         *  --------------- --------------- ---------------  --------------- ---  */
      var
         ptoken = req.body ['_ptk'],
         pname = req.body ['_pn'],
         utoken = req.body ['_pvtk'],
         user_id = req.body ['_ui'];
 
      // 1 - Check Public Token 
      var q, param_value, stateOfRequest = {isOkay:0, err_code:' ERRO_AUTH  PT </> '}, error_des; 
      if(ptoken != APP_CONSTANTS.CONST_PRODUCT_PUBLIC_TOKEN || pname != APP_CONSTANTS.CONST_PRODUCT_NAME )
      {
         res.send( stateOfRequest);return; 
      }

      // 2 - Check Private Token 
      MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
         q =  [ {_id: new ObjectId(user_id) }, {utoken: utoken} ];
         RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne({ $and:q}).then((data)=>{
            stateOfRequest.err_code  = ' ERRO_AUTH  PPT </> ';
            if(data && data['umail'])  
            {
               next();
            } else {
               res.send( stateOfRequest);return; 
            }
         });
      });
   }) 
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 07.10.2021
      * Last Update           : 07.10.2021
      *
      * Description           : Set U Profile
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Set User Profile 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.config_init_set , (req, res, next) => {
         var
            user_id = req.body['ui'],
            user_type = req.body['ut'],  
            user_name = req.body['un'] 
         ;

         var stateOfRequest = {isOkay:0, ut:user_type, err_code:''  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id, un: user_name}, CONST_LOG4JS_CHANNEL.SET_PROFILE, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               q = {_id: new ObjectId(user_id) };
               nd = { utype: user_type};
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data)=>{
                  if( !data.acknowledged)  // Log If Error 
                  {
                     error_des = '(S:R0710211539)';
                     stateOfRequest.err_code = error_des;
                     GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                     res.send(stateOfRequest);return;
                  }
                  stateOfRequest.err_code = '(R0710211625 Or ==)';
                  stateOfRequest.isOkay = data.modifiedCount ? 1 : 0;
                  res.send(stateOfRequest);return;            

               });
            });

         } else {  //  TODO:SET SQL 

         }
   })
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 14.10.2021
      * Last Update           : 14.10.2021
      *
      * Description           : Save a food : Create / Edit 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- If New, save 
      *                          2- Otherwise Edit 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.myfoods_set , (req, res, next) => {
         var
            user_id = req.body['ui'],

            plat_id = req.body['pid'],  
            plat_name = req.body['fn'],  
            plat_price = req.body['fp'],  
            plat_categorie = req.body['fc'],  
            plat_description = req.body['fd'],  
            plat_imagepath = req.body['fip'] 
         ;

        
         var stateOfRequest = {isOkay:0, pid: '', err_code:'', payload:{}, o: plat_id?'1':'0', plat_id:plat_id  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.FOOD_SAVE, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               q = {_id: new ObjectId(user_id) };
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                  var u_plat = data['plats'];
                  var new_food_id  = 0;
                  if(plat_id)  // Edition 
                  {
                     u_plat.map((v,i)=>{
                        if(v.id == plat_id)
                        {
                           u_plat[i].name  =  plat_name;
                           u_plat[i].price  =  plat_price;
                           u_plat[i].pcat  =  plat_categorie;
                           u_plat[i].desc  =  plat_description;
                           u_plat[i].pimg  =  plat_imagepath;

                           stateOfRequest.payload = 
                           {
                              id: plat_id,
                              name : plat_name,
                              price : plat_price,
                              pcat : plat_categorie,
                              desc : plat_description,
                              pimg : plat_imagepath,
                              pdatecreate : v.pdatecreate
                           };
                        }
                     });

                  }  else {   // Create 
                     new_food_id = user_id + '' + (Math.random().toString().slice(3,5)) + '' + (Date.now());

                     var food_data  = 
                     {
                        id: new_food_id,
                        name : plat_name,
                        price : plat_price,
                        pcat : plat_categorie,
                        desc : plat_description,
                        pimg : plat_imagepath,
                        pdatecreate : Date.now()
                     };
                     stateOfRequest.payload = food_data;
                     u_plat.unshift(food_data);
                  }

                  q = {_id: new ObjectId(user_id) };
                  nd = {plats: u_plat};
                  RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                     if( !data_ur.acknowledged)  // Log If Error 
                     {
                        error_des = '(S:R1410211547)';
                        stateOfRequest.err_code = error_des;
                        GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                        res.send(stateOfRequest);return;
                     }

                     stateOfRequest.pid = plat_id ? plat_id : new_food_id;
                     stateOfRequest.isOkay = 1;
                     res.send(stateOfRequest);return;
                  });
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })
   
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 14.10.2021
      * Last Update           : 14.10.2021
      *
      * Description           : List of foods 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- If New, save 
      *                          2- Otherwise Edit 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.myfoods_list , (req, res, next) => {
         var
            user_id = req.body['ui']
         ;

         var stateOfRequest = {isOkay:0, payload:[],  err_code:''  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.FOOD_LIST_ACCOUNT, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               q = {_id: new ObjectId(user_id) };
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                  stateOfRequest.payload = data['plats'];
                  stateOfRequest.isOkay = 1;
                  res.send(stateOfRequest);return;
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })

   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 15.10.2021
      * Last Update           : 15.10.2021
      *
      * Description           : Make Order 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Save order 
      *                          2 - Notify Restaurant by email 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.order_set , (req, res, next) => {
         var
            user_id = req.body['ui'],

            order_name = req.body['on'],  
            restau_ref = req.body['rr'],  
            client_ref = req.body['rc'],  
            order_status = req.body['os'],  
            nb_articles = req.body['ona'],  
            price_total = req.body['opt'],  
            articles_list = req.body['al'],
            order_date = req.body['od'],

            restau_ref_email = req.body['re'],
            restau_ref_name = req.body['rn'],
            mail_order_date = req.body['md']
         ;
        
         var stateOfRequest = {isOkay:0, err_code:''};
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.ORDER_MAKE, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {

               q = { name:order_name, ref_restaurant:restau_ref, ref_client:client_ref,    date_created: order_date,   status:order_status, nb_article:nb_articles,  price_total: price_total,  articles_list: articles_list };
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_ORDERS ).insertOne(q).then((data_2)=> {
                  if( !data_2.acknowledged)  // Log If Error 
                  {
                     error_des = '(S:R1510211200)';
                     stateOfRequest.err_code = error_des;
                     GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                     res.send(stateOfRequest);return;
                  }

                  stateOfRequest.isOkay = data_2.insertedId ? 1: 0;
                  stateOfRequest.err_code = '(S:R1510211226)';
                  res.send(stateOfRequest);

                  // 2 - Send Email To Restaurant
                  var param_extras = q;
                       param_extras.date_ = mail_order_date;
                  var umail = restau_ref_email.slice(3); 
                      umail = Buffer.from(umail, 'base64').toString();
                  GLOBAL_FUNC.write_log({e:restau_ref_email}, CONST_LOG4JS_CHANNEL.BACKEND_OPERATION_LOG, 'info',  '' );

                  var mbs =  MAILER_FUNC.getMailBodySubjet('ORDER_MAKE', APP_CONSTANTS.CONST_APP_LANGUAGE, restau_ref_name, '', param_extras );
                  var email_components = { adress:[umail], subject:[mbs.SUBJECT], body:[mbs.BODY]};
                  var mess_sentresult = MAILER_FUNC.sendEmail( email_components.adress, email_components.subject, [], email_components.body, []);
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })

   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 15.10.2021
      * Last Update           : 15.10.2021
      *
      * Description           : List of Orders : Restaurant + Client 
      *                         _Used also by balance
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- According to user type, Get list of Orders 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.orders_list , (req, res, next) => {
         var
            user_id = req.body['ui'],
            user_type = req.body['ut']
         ;

         var stateOfRequest = {isOkay:0, payload:[],  err_code:''  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.ORDERS_LIST, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               var k = "";
               if(user_type == APP_CONSTANTS.CONST_PRODUCT_APP_ROLE_LIST.RESTAURANT) { k = 'ref_restaurant'; }
               if(user_type == APP_CONSTANTS.CONST_PRODUCT_APP_ROLE_LIST.CLIENT) { k = 'ref_client'; }

               q = {};
               q[k] = user_id;

               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_ORDERS ).find(q).toArray().then((data)=>{
                  stateOfRequest.payload = data;
                  stateOfRequest.isOkay = 1;
                  res.send(stateOfRequest);return;
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })

   
   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 15.10.2021
      * Last Update           : 15.10.2021
      *
      * Description           : Confirm Order 
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1-  Update Data in DB 
      *                          2 - Notify Client
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.orders_confirm , (req, res, next) => {
         var
            user_id = req.body['ui'],

            order_id = req.body['oid'],  
            client_ref = req.body['cref'],  
            order_ref = req.body['oitem']  
         ;
        
         var stateOfRequest = {isOkay:0, err_code:'', order_id:order_id };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.ORDERS_CONFIRM, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               // 1. Update data In DB .............................
               q =  { _id: new ObjectId(order_id)};
               nd = { status: APP_CONSTANTS.CONST_PRODUCT_ORDERS_STATUS.VALIDE  };
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_ORDERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                  if( !data_ur.acknowledged)  // Log If Error 
                  {
                     error_des = '(S:R1510211316)';
                     stateOfRequest.err_code = error_des;
                     GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                     res.send(stateOfRequest);return;
                  }

                  stateOfRequest.isOkay = 1;
                  res.send(stateOfRequest);

                  // 2 - Get Client Mail and send mail  ................
                  q = {_id: new ObjectId(client_ref) };
                  RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                     var 
                        u_mail = data['umail'],
                        u_name = data['uname'];

                     var param_extras = order_ref;
                     var mbs =  MAILER_FUNC.getMailBodySubjet('ORDER_CONFIRM', APP_CONSTANTS.CONST_APP_LANGUAGE, u_name, '', param_extras );
                     var email_components = { adress:[u_mail], subject:[mbs.SUBJECT], body:[mbs.BODY]};
                     var mess_sentresult = MAILER_FUNC.sendEmail( email_components.adress, email_components.subject, [], email_components.body, []);
                  });
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })

   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 15.10.2021
      * Last Update           : 15.10.2021
      *
      * Description           : Privat data : Get
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Get private data of User 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.mydata_get , (req, res, next) => {
         var
            user_id = req.body['ui'],
            user_type = req.body['ut']
         ;

         var stateOfRequest = {isOkay:0, payload:[],  err_code:''  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.MYDATA_GET, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               q = {_id : new ObjectId(user_id)};
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).findOne(q).then((data)=>{
                  stateOfRequest.uname = data['uname'];
                  stateOfRequest.umail = data['umail'];
                  stateOfRequest.uadress = data['uadress'];
   
                  stateOfRequest.restau_name = data['restau_name'];
                  stateOfRequest.restau_location = data['restau_location'];

                  stateOfRequest.isOkay = 1; 
                  res.send(stateOfRequest);
               });
            });

         } else {  //  TODO:SET SQL 

         }
   })

   /** --------------- --------------- --------------- --------------- ---------------
      * endpoint              :  ⬇
      * Begin                 : 15.10.2021
      * Last Update           : 15.10.2021
      *
      * Description           : Privat data : Set
      * 
      * Contributors          :
      *                         Miché KOKORA - <rehum@live.fr>
      * 
      * Algo                  :
      *                          1- Get private data of User 
   *  --------------- --------------- ---------------  --------------- ---  */
   .post(APP_CONSTANTS.CONST_BACKEND_ENDPOINT_LIST.mydata_set , (req, res, next) => {
         var
            user_id = req.body['ui'],
            o_option = req.body['o'],

            user_name = req.body['un'],
            user_mail = req.body['um'],
            user_adresse = req.body['ua'],

            user_restau_name = req.body['ur'],
            user_restau_location = req.body['ul'],

            user_pass = req.body['up']
         ;

         var stateOfRequest = {isOkay:0, payload:[],  err_code:''  };
         var q, nd, param_value, qCount, param_valueCount, error_des, query_string;
         var u_ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
         GLOBAL_FUNC.write_log({ip: u_ip, i: user_id}, CONST_LOG4JS_CHANNEL.MYDATA_SET, 'info', '::');

         if(APP_ENV ==  APP_CONSTANTS._DEVELOPPMENT)
         {
            MONGODB_CONNEXION.MONGODB_CONNECT().then((RESTOO_DB)=> {
               q = {_id : new ObjectId(user_id)};
               nd = {};
               switch (o_option) {
                  case 1: // Private data
                     nd = {uname: user_name, umail: user_mail,  uadress: user_adresse};
                     break;

                  case 2: // Restau 
                     nd = {restau_name:user_restau_name,  restau_location: user_restau_location};
                     break;

                  case 3: // Pass 
                     nd = {  password: CryptoJS.SHA256(user_pass).toString(CryptoJS.enc.Hex)};
                     break;
               
                  default:break;
               }
               RESTOO_DB.collection(MONGODB_SCHEMES.COLLECTION_USERS ).updateOne(q, {$set:nd}).then((data_ur)=>{
                  if( !data_ur.acknowledged)  // Log If Error 
                  {
                     error_des = '(S:R1519211806)';
                     stateOfRequest.err_code = error_des;
                     GLOBAL_FUNC.write_log({}, CONST_LOG4JS_CHANNEL.BACKEND_DATABASE_OPERATION_ERROR, 'error',  JSON.stringify( error_des) );
                     res.send(stateOfRequest);return;
                  }
                  stateOfRequest.isOkay = 1;
                  res.send(stateOfRequest); return; 
               });  
            });

         } else {  //  TODO:SET SQL 

         }
   })


   
   ;



/** ------------------------------ C R O N  ------------------------------ */
/** ------------------------------ D E F A U L T   ------------------------------ */
appRouter
   .get("*", (req, res) => {
      GLOBAL_FUNC.write_log({u_ip: req.ip }, CONST_LOG4JS_CHANNEL.BACKEND_URL_ERROR, 'info', ' MISSING_URL_ACCESSING :: /  ' + req.url );
      res.sendFile(__dirname + '/assets/pages/index.html'); 
   });

var path_be = '/be';
app.use(path_be,  appRouter);                  
app.use(path_be,  appPublicRouter);          
app.use(path_be,  appProtectedRouter);

/** -----  LISTEN : PROD | DEV   --------------------------------------- */
(APP_ENV  == 'PROD') ?
   server.listen() : 
   server.listen(port, hostname, ()=>{ console.log('Server Running on Port:: ' +   port + '  --Hostname:: ' + hostname + '  --ENV ' + APP_ENV  +  ' ' + (Date.now()) );  });