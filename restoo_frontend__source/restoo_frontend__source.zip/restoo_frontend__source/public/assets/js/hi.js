alert('KOKORA');
console.log('I AM LA ');
