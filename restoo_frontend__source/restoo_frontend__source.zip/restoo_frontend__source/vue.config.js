module.exports = {
  transpileDependencies: [
    'vuetify'
  ]
}
