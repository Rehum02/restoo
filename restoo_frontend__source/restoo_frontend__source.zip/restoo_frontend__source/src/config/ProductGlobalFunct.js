
// <!-- ============================================================+
// File name   : ProductGlobalFunc.js
// Begin       : 06.10.21
// Last Update : 06.10.21
//  
// Description : Contain Project Global Functions 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 


// ---------------- GET FILES  ----------------
import ProductConstant from "./ProductConstant";
import * as CryptoJS from 'crypto-js';


export default {
   
    /**@f_generate_color Generate color  */
    f_generate_color: function(){
        var r = Math.floor(Math.random() * 255);
        var g = Math.floor(Math.random() * 255);
        var b = Math.floor(Math.random() * 255);
        return "rgb(" + r + "," + g + "," + b + ")";
    },
    /** @f_goto  GoTo A Location @param o Option @param u Url @param context @param open_option _blank | _self */
    f_goto: function(o, u, context, open_option=null){
        var this_ = context;
        switch (o) {
            case 1:  // Internal Path 
                this_.$router.push(u);
                break;

            case 2:  // Internal Path 
                window.open(u, open_option, 'noreferrer=yes, noopener=yes');
                break;
        }
    },
    /** @f_set_toast Show Toast  @param o true:show | false:hide  @param msg message to show  @param  timeout timeout  @param color Color Of Toast  @param context Context Of element */
    f_set_toast:function(o, msg, timeout, color, context  ){
        var  this_ = context;
        this_.toast.on = o;
        this_.toast.msg = msg;
        this_.toast.timeout = timeout;
        this_.toast.color = color ;
    },

    /** @f_set_titlemeta Update Title - Meta  @t Title  @m  Meta Atribute   @mv Meta Content   */
    f_set_titlemeta:function(t,m=null, mv=null){
        document.title = t;
        let q = document.querySelector( 'meta' + m);
        q?.setAttribute('content', mv);
    },

    /** @f_short_sentence  Shorten a sentence    @param {*} s Sentence @param {*} limit Limit  */
    f_short_sentence:function(s, limit){  
        return  (s.length > limit) ? s.slice(0, limit) + ' ... ' : s;
    },

    /** @f_avg  Compute Avg of array @param arr Array to compute  */
    f_avg: function(arr){  
        if(!arr.length) { throw new Error('No Array'); }

        var arr_sum = 0; 
        for (var i = 0; i < arr.length; i++) { arr_sum += arr[i]}
        return (arr_sum/arr.length);
    },

    /** @f_isMobile Detect Mobile : We assume mobile by size   */
    f_isMobile:function(){
        var isMobile = window.matchMedia("only screen and (max-width: 760px)");
        return isMobile.matches ? true : false
    },
    
    /** @f_get_lang Get User Browser Language * @return lg*/
    f_get_ulang:function () {
        let lg = navigator.language.split('-').shift();
        let sv = localStorage.getItem( ProductConstant.CONST_PRODUCT_STORAGE_LANGUAGE);

        let lg_f =  "";
        if( sv  &&  (ProductConstant.CONST_APP_LANGUAGE_LIST_SIMPLE.indexOf(sv) != -1) )
        {
            return sv; 
        } 

        lg_f = ProductConstant.CONST_APP_LANGUAGE_LIST_SIMPLE.indexOf(lg) != - 1 ?  lg : ProductConstant.CONST_APP_LANGUAGE_DEFAULT;
        return lg_f;
    },
    
    /** @f_ga  Integrate  Google Analytics  @param l Page URL */
    f_ga:function(l){
        let w = window.dataLayer;
        w  = w || [];
        function gtag(...args){  w.push(args);}
        gtag('js', new Date());
        gtag('config', ProductConstant.CONST_GOOGLE_ANALYTICS_ID , {'page_path': l});
    },

    /** @f_getdate : GET DATE  YYYY-MM-DD HH:MM:SS  @param dat Date  @param o Option */
    f_app_getdate:function(dat, o=('FULL'||'NO_SS')){
        let d = dat? new Date(dat):  new Date();
                
        let dy = d.getFullYear();
        let dm =   this.f_add_zero( d.getMonth()+1 );
        let dD =   this.f_add_zero(d.getDate());
        let dh =   this.f_add_zero(d.getHours());
        let dmin =   this.f_add_zero(d.getMinutes());
        let dsec =   this.f_add_zero(d.getSeconds());

        let fd = '';
        switch (o) 
        {
            case 'FULL':
                fd = dy + '-' +  dm + '-' +  dD + ' ' + dh + ':' + dmin + ':' + dsec;
                break;

            case 'NO_SS':
                fd = dy + '-' +  dm + '-' +  dD + ' ' + dh + ':' + dmin;
                break;
                
            default:break;
        }

        return fd;
    },
    
    /** @f_add_zero Add Zero to date */
    f_add_zero:function (d){ return (d < 10) ?  "0" + d : d;},

    /** @f_date_toappdateformat  Transform date to app date format  */
    f_date_toappdateformat:function(dat){
                var d = new Date(dat);
                var day = d.getUTCDate();
                    day = day < 10 ? '0' + day : day;
                var month = (d.getUTCMonth() + 1);
                    month = month < 10 ? '0' + month : month;
                var year = d.getUTCFullYear();
                var h = (d.getUTCHours());
                    h = h < 10 ? '0' + h : h;
                    h =  h + 'h';
                var m = (d.getUTCMinutes());
                    m = m < 10 ? '0' + m : m;
                    m =  m + 'min';
                var t = day + ', ' + month + '-' + year + ' ' + h + '' + m;

                return t;
    },
 
    /** @f_scroll_to  Scroll to Element  @d DomElement */
    f_scroll_to:function (d){
        let div =  document.querySelector(d);
        div?div.scrollIntoView({behavior:'smooth'}): null;
    },
 
    /** @f_check_pass_strength Check Pass Strength  : 8 charactères et comprendre au moins 1 lettre majuscule, 1 lettre minuscule, 1 chiffre, 1 caractère non-alphanumérique(+ , - *, etc)  @param o : Password */
    f_check_pass_strength:function(p){
        return (p && /\d/.test(p) && /\w/.test(p) && /\W/.test(p) && p.length >= 8 && /[A-Z]/.test(p) && /[a-z]/.test(p));
    },
 
    /** ----------------------- CRYPTAGE ----------------------- */
    /** @f_udecryptparse Decrypt & Parse data @param data data to crypt*/
    f_udecryptparse:function (data){
        var ciphertext = localStorage.getItem(data);
        if(!ciphertext){ return ''; } 
                
        var plain=  this.f_aes_decrypt(ciphertext, 'PLAINTEXT');
        var u_data = JSON.parse(plain);
        return u_data;
    },
    /** @f_aes_enc Cryptage AES   @param data data to crypt     @param rf: Return Format */
    f_aes_encrypt:function ( data, rf= ('B64'||'HEX')){
        var b64= CryptoJS.AES.encrypt(data,  ProductConstant.CONST_PRODUCT_C_KEY).toString();
        var eHex;
        switch (rf) {
            case 'B64':
                break;
            case 'HEX':
                var e64 =   CryptoJS.enc.Base64.parse(b64);
                eHex = e64.toString(CryptoJS.enc.Hex);
                break;
            default:break;
        }

        return eHex;
    },

    /** @f_aes_decrypt DecCryptage AES     @param data data to decrypt     @param rf: Return Format  */
    f_aes_decrypt:function (data,  rf= ('PLAINTEXT') ){
        var reb64 = CryptoJS.enc.Hex.parse(data);
        var bytes = reb64.toString(CryptoJS.enc.Base64);
        var decrypt;
        var plain;

        switch (rf) {
            case 'PLAINTEXT':
                decrypt = CryptoJS.AES.decrypt(bytes, ProductConstant.CONST_PRODUCT_C_KEY);
                plain = decrypt.toString(CryptoJS.enc.Utf8);
                break;
                
            default:break;
        }

        return plain;
    },

    /** @f_md5_encrypt Crypt some data in MD5   @param data data to crypt     @param rf: Return Format */
    f_md5_encrypt:function (data, rf= ('HEX')){
        console.log(rf);
        var c = CryptoJS.MD5(data).toString(CryptoJS.enc.Hex);
        return c;
    },

    /** * @f_set_cookies  SET COOKIES   @param {string} name: name Of Cookies * @param {any} val:  value of Cookies * @param {number} days: Nombre Of Days Before Expire domain=xx.com; */
    f_set_cookies:function (name,val, days){
        var d = 3600 * 24 * days;
        document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(val) + " ; path=/; samesite=lax; max-age=" + d;
    },
    /** * @f_get_cookies  GET COOKIES   * @param {string} name: name Of Cookies */
    f_get_cookies:function (name){
        var s = name+"=";
        var c = document.cookie.split(';'), e = '', v = '';
        for (let i = 0; i < c.length; i++) {
            e = decodeURIComponent(c[i].trim());
            if(e.indexOf(s) != -1)
            {
                v =  e.substring(s.length);
                break;
            }
        }
        return v;
    },

    /** * @f_delete_cookies  SET  COOKIES   * @param {string} name: name Of Cookies */
    f_delete_cookies:function(name){ this.f_set_cookies(name, '', -1);}
}