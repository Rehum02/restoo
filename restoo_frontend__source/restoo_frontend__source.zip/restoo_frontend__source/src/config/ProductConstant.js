
// <!-- ============================================================+
// File name   : ProductConstants.js
// Begin       : 06.10.21
// Last Update : 06.10.21
//  
// Description : Contain Project Constant 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                      Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 


export default {
        /** ------------------- OWNER DATA ------------------- */
        CONST_OWNER_WEBSITE:'https://restoo.nsiyo.com',
        CONST_OWNER_ACCOUNT_MAIN:'https://restoo.nsiyo.com',
        CONST_OWNER_NAME:'Restoo',
        CONST_OWNER_ADRESSE:" Côte d'Ivoire, Abidjan Cocody Riviera Golf",
        CONST_OWNER_SUPPORT_EMAIL:"support@restoo.com",
        CONST_OWNER_PHONE_NUMBER:"07 47634218",
                

        /** ------------------- APP CONFIG ------------------- */
        CONST_PRODUCT_NAME:"Restoo",
        CONST_PRODUCT_SUPPORT_EMAIL:"support@restoo.com", 
        CONST_PRODUCT_SLOGAN:
        {
            fr: "Commandez, vous êtes livrés",
            en: "Command, you receive your order"
        },
        CONST_PRODUCT_DESCRIPTION:
        {
            fr: "Vos plats preférés proches de vous",
            en: "Your favorites foods near of you ",
        },
        CONST_PRODUCT_ID:1,

        CONST_PRODUCT_STORAGE_EM_PRODUCT:"_rst",
        CONST_PRODUCT_STORAGE_T_SET:"_rt",   
        CONST_PRODUCT_C_KEY:"RE_MIK&MI#BRstoo2021_@K!",
        CONST_PRODUCT_STORAGE_UI:"_ui",
        CONST_PRODUCT_STORAGE_LANGUAGE:"_lg", 
        CONST_PRODUCT_STORAGE_VAR_DEVICEID:"_nd", 
        CONST_PRODUCT_STORAGE_LANG_PATH:"_lp", 
        CONST_PRODUCT_STORAGE_PROCESSING:"_pl",   // 1: lang
        CONST_PRODUCT_PUBLIC_TOKEN:"60+GAldjkqlmh563°+*HJGGK21U7BX!.:MIK&MI#BRstoHGo2021_@K!",
        
        CONST_PRODUCT_VERSION_INIT:'1.0.0',
        CONST_PRODUCT_VERSION_CURRENT:'1.0.0',

        
        CONST_PRODUCT_APP_ROLE_LIST_ALL:['1','2'],  
        CONST_PRODUCT_APP_ROLE_LIST:{ RESTAURANT :'1', CLIENT:'2'},
        CONST_PRODUCT_APP_ROLE_LIST_REVERSE:{ _1: 'RESTAURANT', _2: 'CLIENT'},
        CONST_PRODUCT_VALIDECODE_OPTION:{ SIGNUP_VALIDE:1, PASSRESET_VALIDE:2},
        CONST_PRODUCT_ORDERS_STATUS_LIST:[{ v: 1, n: 'VALIDE'},  {v:0, n:'NON_VALIDE'}],
        CONST_PRODUCT_ORDERS_STATUS:{ VALIDE:1, NON_VALIDE: 0},
        CONST_PRODUCT_ORDERS_STATUS_INVERSE:{ _1:'VALIDE', _0:'NON_VALIDE'},
        
        CONST_BASE_FETCH_LIMIT_NO:'*',
        CONST_BASE_FETCH_LIMIT_PICKONE:'1',
     
        CONST_BASE_SNACBAR_NOTIF_STYLE:
        {
            error:  'red white--text',
            success: 'green white--text',
            info: 'blue white--text',
            warning: 'orange black--text'
        },

        CONST_PLATS_CATEGORIES:
        [
            {code_s: 'pl01at', label:{fr:'Plats africains', en:'African foods'}, icon: 'school', color:'#760b84',  class:'i1'},
            {code_s: 'pl02bt', label:{fr:'Plats europeens', en:'Europeans foods'}, icon:'smartphone', color:'blue', class:'i2' },
            {code_s: 'pl03ct', label:{fr:'Plats asiatiques', en:'Asian foods'}, icon:'sports_esports', color: '#fda0a5', class:'i3' },
            {code_s: 'pl04dt', label:{fr:'Plats americains', en:'American foods'}, icon:'web_asset', color:'#474343', class:'i4'},
        ],
      
  
        /** ------------------- FINANCE ------------------- */
        CONST_PRODUCT_DEVISE:'F CFA',
        CONST_PRODUCT_MEMBERSHIP_NOT_UPDATE_MSG:
        {
            header : {fr:"😞 Votre compte n'est pas à jour", en:' 😞 Your membership is not up-to-date ',  es:'😞 Tu membresía no está actualizada'},
            content : 
            {
                fr:"  Veuillez regler votre facture d'abord ", 
            },
            btn_cancel : {fr:"Prochainement", en:'Later',  es:'Próximamente'},
            btn_confirm : {fr:"Okay", en:'Okay',  es:'Ok'},
        },

        /** ------------------- LANGUAGES  ------------------- */
        CONST_APP_LANGUAGE_DEFAULT:'fr',
        CONST_APP_LANGUAGE_LIST_SIMPLE:['fr'],  // ['fr', 'en'],
        CONST_APP_LANGUAGE_SERVER:['fr', 'en'],
        CONST_APP_LANGUAGE_SERVER_DEFAULT:'en',
        CONST_APP_LANGUAGE_LIST_OBJECT:
        [         
            {   name : "Français", value: "fr_FR", value_simple: "fr", flag:'assets/flag/fr.svg.png' },
            {   name : "English", value: "en_US", value_simple: "en",  flag:'assets/flag/en.svg.png' }
        ], 

        CONST_EMAIL_FORMAT:/^[\w\-_.]+@[\w.\-_]+\.[\w.\-_]+$/,
        CONST_LINK_FORMAT:/((https?):\/\/[^\s]+)/,
        CONST_PHONE_FORMAT:/\+(\d)+/,
        CONST_IMAGE_BASE64:/^data:image\/[^,]+,base64,/,

        /** ------------------- APP - THEMING    ------------------- */
        CONST_PRODUCT_APP_COLOR_MAIN:'tertiary',
        CONST_GRAPH_COLOR:
        {
            bar_1: '#3388ff',
            bar_2: '#d38080',
        },
        CONST_BASE_DELIMITER_CARACTER:'__',
        CONST_DATE_TITLE:
        {
            Y: {fr:'ANNÉE', en:'YEAR', es:'AÑO'},
            M: {fr:'MOIS', en:'MONTH', es:'MES'},
            D: {fr:'JOUR', en:'DAY', es:'DIA'},
            H: {fr:'HEURE', en:'HOUR', es:'HORA'},
            m: {fr:'MINUTES', en:'MINUTES', es:'MINUTOS'}
        },

        /** ------------------- APP - ERROR MANAGEMENT     ------------------- */
        CONST_PRODUCT_ERROR_DATANOTSENT:
        {
            fr: "Erreur de transmission des données. ... Verifiez votre connexion et réssayez",
            en: "Error Sending data. ... Please, Check your internet connection and try again ",
            es: "Error de transmisión de datos. ... Verifique tu conexión e intente nuevamente "
        },
        CONST_PRODUCT_ERROR_DATASENTNOTBACK:
        {
            fr: "Erreur imprévue. Impossible d'effectuer cette tâche. Joignez-nous si cela persiste",
            en: "Unexpected Error. Unable to complete this task. Join us if this persists ",
            es: "No Esperando este error. No se puede completar esta tarea. Únete a nosotros si esto persiste "
        },
        CONST_PRODUCT_ERROR_IMPREVUE:
        {
            fr: "Erreur imprévue",
            en: "Unexpected Error"
        },

        /** ------------------- APP INTERNAL + EXTERNAL PATH SETTING ------------------- */
        /** The 1st || 2nd  part of relative url must be the same of the property name  :: Used in guard */
        CONST_PAGE_URL_LIST:
        {
            // ------------------------- GLOBAL  -------------------------
            phome: { path: '/', role: [],  menu_item:0, icon:'', label: {fr:'-', en:'-', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0' },
            auth: { path: '/auth', role: [],  menu_item:0, icon:'', label: {fr:'-', en:'-', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0' },
                    
            // ------------------------- RESTAURANT  -------------------------
            rmyfoods: { path: '/account/rmyfoods', role: ['1'],  menu_item:1, icon:'home', label: {fr:'Accueil', en:'Home', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0' },
            rmybalance: { path: '/account/rmybalance', role: ['1'],  menu_item:1, icon:'home', label: {fr:'Accueil', en:'Home', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0' },
                    
            // ------------------------- CLIENT  -------------------------
                    
            // ------------------------- BOTH  -------------------------
            myorders: { path: '/account/myorders', role: ['1', '2'],  menu_item:1, icon:'home', label: {fr:'Accueil', en:'Home', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0' },
            mydata: { path: '/account/mydata', role: ['1', '2' ],  menu_item:1, icon:'paid', label: {fr:'Mon argent', en:'My money', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0' },
            setup: { path: '/u/setup', role: ['1', '2' ],  menu_item:1, icon:'settings_applications', label: {fr:'Configuration initiale', en:'Account setup', es:''}, class:'', badge_number:0, badge_color:'', externalink:'0', name:'setup' },
        },

        CONST_BACKEND_ENDPOINT_LIST:
        {
            // AUTHENTIFICATION 
            sign_up:'sign_up',
            valide_code:'valide_code',
            sign_in:'sign_in',
            passreset_init:'passreset_init',
            
            // ACCOUNT 
            config_init_set:'config_init_set',
            
            myfoods_set:'myfoods_set',
            myfoods_list:'myfoods_list',
            
            order_set:'order_set',
            orders_list:'orders_list',
            orders_confirm:'orders_confirm',
            
            mydata_get:'mydata_get',
            mydata_set:'mydata_set',
            
            foods_list:'foods_list',
        },

        CONST_APP_PROTOCOLE:'rst::',  
        CONST_INDEX_ROOT:'https://restoo.nsiyo.com',
        
        CONST_SERVICE_PAY_PAGE_FULL:'',
        CONST_USERGUIDE: '',       // 
        CONST_PRODUCT_VITRINE: '', //  

        CONST_FRONTEND_ROOT_PATH:'https://restoo.nsiyo.com/',               //  Test : http://localhost:8080
        CONST_BACKEND_ROOT_PATH: 'http://localhost:8000/be/',                  //  'https://be.restoo.nsiyo.com/be/',         //  Test :  http://localhost:8000
        CONST_INDEX_RESOURCE_PATH:'https://be.restoo.nsiyo.com/upldser/', 
        
        /** ---------------  THIRD PARTY SERVICES --------------- */
        CONST_GOOGLE_ANALYTICS_ID:'',
        CONST_3rd_SERVICE_API:{},
        CONST_PRODUCT_PLAYSTORE_ID:'',
        CONST_PRODUCT_PLAYSTORE_LINK:"", // https://play.google.com/store/apps/details?id=io.ephmi.nsiyo",
        CONST_PRODUCT_APPLESTORE_ID:'',      
        CONST_PRODUCT_APPLESTORE_LINK: '',
};
