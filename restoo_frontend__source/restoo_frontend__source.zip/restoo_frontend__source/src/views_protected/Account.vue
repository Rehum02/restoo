<!-- ============================================================+
// File name   : Account.vue
// Begin       : 14.10.21
// Last Update : 14.10.21
//  
// Description : Account Vue 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
  <v-app>
      <!-- BAR  dense dark dense dark -->
      <v-app-bar color="primary"  app height >
            <div style="width:100%" class="text-center  text-xl-h4 text-lg-h4 text-sm-h4 text-h4 white--text font-weight-normal  cursor_p"  @click="f_goto_local(1, m_link.home)">  {{app_product_name}}    </div>
            <v-spacer></v-spacer>
            <template v-slot:extension >
              <v-tabs  grow align-with-title  center-active dark >
                <v-tab v-for="item in tabs.tablist" :key="item.id"  @click="f_goto_local(1, item.p)">
                  {{item.n}} 
                </v-tab>
              </v-tabs>
            </template>
      </v-app-bar>

      <!-- CONTENT -->
      <v-main>
        <v-container fluid style="width:100%; height:100%; padding:0" >
          <router-view></router-view>
        </v-container>
      </v-main>
  </v-app>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
  .v-card{ min-height:340px !important ; }
</style>


<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
// import AccountService from '../services/AccountService'

// ----------- SOME GLOBAL VAR  -----------
var u_data={};   // s = {}, 

export default {
  name: 'Account',
  data() {
    return {
      app_uPID:'',app_uToken:'', app_uName:'',
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,
      m_link:{ home: ProductConstant.CONST_PAGE_URL_LIST.phome.path },
      
      tabs: 
      {
        model: '',
        tablistbase:
        [
          { n: 'Mes Commandes',  p: ProductConstant.CONST_PAGE_URL_LIST.myorders.path, role:['1', '2'], id:1  },
          { n: 'Mes Plats',  p: ProductConstant.CONST_PAGE_URL_LIST.rmyfoods.path, role:['1'], id:2   },
          { n: 'Ma Balance ',  p: ProductConstant.CONST_PAGE_URL_LIST.rmybalance.path, role:['1'], id:3   },

          { n: 'Mes Données Personnelles',  p: ProductConstant.CONST_PAGE_URL_LIST.mydata.path, role:['1', '2'], id:4   },
        ],
        tablist:[]
      },
      loading:{ signup:false },
      showbox:{platcreatedit:false},
      toast:{ on: false, timeout: 5000, msg: '', color:'' }
    };
  },
  created() {
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        this.app_uPID = u_data.ui;
        this.app_uToken = u_data.utk;
        this.app_uName = u_data.un;
        this.app_uType = u_data.ut;
    }

    this.tabs.tablist = this.tabs.tablistbase.filter((v)=>v.role.indexOf( this.app_uType ) != - 1);
  },
  mounted() {},
  methods: {
    /** @f_goto_local Go to @param o Option @param p Path   */
    f_goto_local:function(o, p){
      ProductGlobalFunct.f_goto(o, p, this);
    },
  },
}
</script>



