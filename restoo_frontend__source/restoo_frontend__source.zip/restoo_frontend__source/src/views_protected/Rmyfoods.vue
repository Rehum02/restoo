<!-- ============================================================+
// File name   : Rmyfoods.vue
// Begin       : 14.10.21
// Last Update : 14.10.21
//  
// Description : Manage Foods for a restaurant 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->
<template>
  <div class="grey lighten-4 w100 h100 pa-5"  id="Rmyfoods"  >
    
    <!-- ACTION BTN  -->
    <v-row  class="animate__animated  animate__fadeIn" >
      <v-col xl="12" lg="12" md="12" sm="12" xs="12" >
          <v-btn class="white--text rounded text-capitalize " color="secondary"  @click="f_showbox(2, 'platcreatedit', m_page_caract.create )"> Enregistrer un plat  </v-btn>
      </v-col>
    </v-row>

    <!-- EMPTY DIVIDER  -->
    <v-row>
      <v-col xl="12" lg="12" md="12" sm="12" xs="12" >
          <v-divider></v-divider>
      </v-col>
    </v-row>

    <!-- LISTE + DETAILS  -->
    <v-row>
      <v-col xl="4" lg="4" md="5" sm="5" xs="12"  v-if="(showbox.section == '1' && is_mobile) || !is_mobile " >
        <div class="white rounded pa-1  animate__animated  animate__slideInLeft " >
          <!-- TITLE  -->
          <h4 class="text-center" >  Liste des plats   </h4>
          <v-divider class="mt-3 mb-3" ></v-divider>
          
          <!-- SEARCH BAR  -->
          <v-text-field type="text"  placeholder="... Chercher un plat "  v-model="list.search"  @keyup="f_search(1, $event)" v-if="list.list_base.length" ></v-text-field>
        
          <!-- NO DATA YET  -->
          <div  v-if="!list.list_shown.length" class="text-center pa-3 mt-3"  :style="{'min-height':list.height/2 +'px'}"  >
              La liste des différents plats de votre restaurant apparaitra ici
             <div align="center" justify="center" >
                  <v-icon  color="secondary" style="font-size:130px"> mdi-food</v-icon>
              </div>
          </div>

          <!-- LIST  : DATA EXIST -->
          <v-list-item-group v-model="list.selecteditem" color="secondary"  :style="{'max-height':list.height+'px', 'min-height':list.height/2 +'px', 'overflow-y':'auto'}"  v-if="list.list_shown.length" >
            <v-list-item v-for="item in list.list_shown" :key="item.id"  @click="f_details(item.id, item)"  >
              <v-list-item-icon>
                <v-icon> mdi-food  </v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title v-text="item.name"></v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
          
          <!-- LOAD MORE: No  -->

        </div>
      </v-col>
      <v-col xl="1" lg="1" md="1" sm="1" xs="1"  class="d-xl-block d-lg-block d-md-block d-sm-block  d-none"></v-col>
      <v-col xl="7" lg="7" md="6" sm="6" xs="12" v-if="(showbox.section == '2' && is_mobile) || !is_mobile " class="animate__animated animate__fadeInRight"  >
        <div class="white rounded pa-1 animate__animated  animate__slideInRight" >

           <!-- RETOUR -->
          <v-chip @click="f_switcher(showbox._section_list)" v-if="is_mobile" >
              <v-avatar left> <v-icon>mdi-chevron-left</v-icon> </v-avatar>
              Retour 
          </v-chip>

          <!-- TITLE  -->
          <h4 class="text-center" >  Details </h4>
          <v-divider class="mt-3 mb-3" ></v-divider>
          
          <!-- NO CONTENT YET  -->
          <div v-if="!m_page_caract.pid"  align="center"  justify="center" class="text-center pa-3 mt-3"  :style="{'min-height':list.height/2 +'px' }"  >
              <span> Les données d'un plat apparaitront ici  </span>
              <div align="center"  justify="center">
                  <v-icon  color="secondary" style="font-size:130px"> mdi-food</v-icon>
              </div>
          </div>

          <!-- CONTENT  -->
          <div v-if="m_page_caract.pid"  :style="{'min-height':list.height/2 +'px'}">
            <!-- ACTION BTN -->
            <div class="pa-1 d_flex jcfe animate__animated  animate__fadeIn mt-2 mb-2" >
              <v-btn class="white--text rounded text-capitalize " color="secondary"  @click="f_showbox(2, 'platcreatedit', m_page_caract.edit )"> Modifier  </v-btn>
            </div>
            <v-divider></v-divider>

            <!-- DETAILS CONTENT -->
            <div class="pa-3 ml-5" >
                <!-- IMG : class="d_flex aic jcc"-->
                <p class="mb-4" >
                  <v-img
                      :lazy-src="details.food_img"
                      max-height="183"
                      max-width="276"
                      aspect-ratio="1"
                  >
                      <template v-slot:placeholder v-if="!details.food_img" >
                        <v-row
                          class="fill-height ma-0 grey lighten-2 "
                          align="center"
                          justify="center"
                        >
                          <v-progress-circular indeterminate color="grey lighten-5"></v-progress-circular>
                        </v-row>
                      </template>
                  </v-img>
                </p>
                <!-- NOM -->
                <p class="font-weight-bold mb-4" > {{details.food_name}} </p>
                <!-- PRICE -->
                <p class="mb-4" > {{details.food_price}} F CFA  </p>
                <!-- CATEGORIE -->
                <p class="mb-4"> {{details.food_cat}}</p>
                <!-- DESC -->
                <p class="mb-4"> {{details.food_descr}}</p>
                <!-- DATE ENREGISTREMENT  -->
                <p class="mb-4"> {{details.food_datecreate}}</p>
            </div>
          </div>

        </div>
      </v-col>
    </v-row>

    <!-- DRAWER : CREATION / EDITION PLAT  -->
    <v-navigation-drawer absolute temporary right v-model="showbox.platcreatedit"  class="d_flex dr "  style="flex-direction: column;"   >
        <!-- BODY -->
        <div>
            <v-list-item>
                <v-list-item-avatar  @click="f_showbox(1, 'platcreatedit')"  class="cursor_p" >
                  <v-icon> mdi-menu </v-icon>
                </v-list-item-avatar>
                <v-list-item-content>
                  <v-list-item-title class="text-center" >
                    <p class="text-xl-h5 text-lg-h5 text-sm-h5 text-h5 ">  {{form._title}}  </p>
                  </v-list-item-title> 
                </v-list-item-content>
            </v-list-item>
        
            <v-divider></v-divider>
        
            <v-list :style="{'max-height':((list.height/2)+90) + 'px', 'overflow-y':'auto'}" > 
                <!-- NOM DU PLAT  -->
                <v-list-item>
                  <v-list-item-content>
                    <v-text-field type="text"  placeholder="..."  label="Le nom du plat" v-model="form.name" ></v-text-field>
                  </v-list-item-content>
                </v-list-item>
        
                <!-- PRIX  -->
                <v-list-item>
                  <v-list-item-content>
                    <v-text-field type="number"  placeholder="..."  label="Le prix du plat" v-model="form.prix" suffix="F CFA"  ></v-text-field>
                  </v-list-item-content>
                </v-list-item>
        
                <!-- CATEGORIE  -->
                <v-list-item>
                  <v-list-item-content>
                    <v-select v-model="form.cat" :items="form.catlist" item-text="label.fr" item-value="code_s" label="Catégorie du plat" return-object></v-select>
                  </v-list-item-content>
                </v-list-item>
        
                <!-- BREVE DESCRIPTION   -->
                <v-list-item>
                  <v-list-item-content>
                    <v-textarea  placeholder="... "  label="Brève description du plat" v-model="form.bdesc" auto-grow counter  rows="1" ></v-textarea>
                  </v-list-item-content>
                </v-list-item>
        
                <!-- IMAGE UPLOAD ::    -->
                <div> <file-pond ref="fpond_1" name="filepond"  @init="f_initfilepond"/> </div>
            </v-list> 
        </div>

        <!-- ACTION BTN  -->
        <div class="mt-auto  w100 animate__animated  animate__fadeInUp">
            <v-btn class="text-center w100 mt-5 " color="secondary"  :loading="loading.save" @click="f_save_food()" > Enregistrer </v-btn>
        </div>
    </v-navigation-drawer>
    
    <!-- LOADING BAR  -->
    <v-progress-linear indeterminate  style="position:fixed; bottom:0.5em" v-if="loading.main"  ></v-progress-linear>

    <!-- SNACKBAR :PROCESS -->
    <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
      {{toast.msg}}
      <template v-slot:action="{ attrs }">
        <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
      </template>
    </v-snackbar>

  </div>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
.dr{ min-width: 400px;  }

@media screen  and (max-width:760px){
  .dr{ width:80%}
} 
</style>


<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'
import '@/assets/restoo.css';

import vueFilePond from 'vue-filepond';
import { setOptions } from 'filepond';
import FilePondPluginFileValidateSize from 'filepond-plugin-file-validate-size';
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type';
import FilePondPluginImagePreview from 'filepond-plugin-image-preview';
import FilePondPluginImageResize from 'filepond-plugin-image-resize';
import FilePondPluginImageCrop from 'filepond-plugin-image-crop';
import FilePondPluginImageExifOrientation from 'filepond-plugin-image-exif-orientation';
import FilePondPluginImageTransform from 'filepond-plugin-image-transform';
import FilePondPluginFileRename from 'filepond-plugin-file-rename';

import 'filepond/dist/filepond.css'
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css';


const FilePond = vueFilePond(
    FilePondPluginFileValidateType,
    FilePondPluginFileValidateSize,
    FilePondPluginImagePreview,
    FilePondPluginImageResize,
    FilePondPluginImageCrop,
    FilePondPluginImageExifOrientation,
    FilePondPluginImageTransform,
    FilePondPluginFileRename
  );

// ----------- SOME GLOBAL VAR  -----------
var u_data={}, s = {};

export default {
  name: 'Rmyfoods',
  data() {
    return {
      app_uPID:'',app_uToken:'', app_uName:'',
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,

      m_page_caract:{ create: '0', edit: '1',   pid: ''},
      list :{
        search:'',   
        list_base:
        [
          {id:1, title:'Kedjenou de Poulet ',  price:2000, desc:''},
        ],  
        list_shown:[],
        index:0,
        all:0,
        selecteditem:'', 
        height : window.screen.height - 100
      },
      showbox:{ platcreatedit:false, section:'1',_section_list:'1', _section_details:'2'},
      toast:{ on: false, timeout: 5000, msg: '', color:'' },
      form:{
        _title:"Enregistrement d'un plat",
        _title_base:{
          _0: "Enregistrement d'un plat",
          _1: "Edition  du plat", 
        },
        name: '', prix:null, catlist : ProductConstant.CONST_PLATS_CATEGORIES, cat: '',bdesc:'', imgpath:''
      },
      details:{ food_img:'', food_name:'', food_price:'', food_cat:'', food_descr:'', food_datecreate:'' }, 
      loading: { save:false, main: false },
      is_mobile : false 
    };
  },
  mounted() {
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        this.app_uPID = u_data.ui;
        this.app_uToken = u_data.utk;
        this.app_uName = u_data.un;
    }

    this.is_mobile = ProductGlobalFunct.f_isMobile();
    this.f_initfilepond();
    this.f_get_foods_list();
  },
  methods: {
    /** @f_initfilepond Init FilePond   */
    f_initfilepond:function(){
      setOptions(
        { 
          class: 'my-filepond',           // className: '',
          allowDrop : true,               // Enable or disable drag n’ drop
          allowMultiple: true,            // Enable or disable adding multiple files
          allowRevert:true,
          labelIdle:' Sélectionnez une image du plat',
          maxFiles: 1,                    // The maximum number of files that the pond can handle // acceptedFileTypes:,  // maxFileSize: '5MB',            // imageCropAspectRatio: '1:1',  imageResizeTargetWidth: 400, 
          instantUpload: true,            // Immediately upload new files to the server
          fileRenameFunction: (file) => {     /** Renaming data  */
              var b = Date.now();
              var r = Math.random().toString().slice(2, 5);
              var fn  = 'PI' + this.app_uPID + '_' + (r) + '' + (b) + file.extension;
              return fn;
          },
          server: {                       // SERVER END POINT   
                url: ProductConstant.CONST_INDEX_RESOURCE_PATH,
                process: {
                    onload: (response) => {  
                      this.form.imgpath = response;
                    }
                }
          }
        }
      )
    },
    /** @f_save_food  Save Food : */
    f_save_food:function(){
      // Checking  data  ...
      if(!this.form.name || !this.form.prix ||  !this.form.cat ||  !this.form.bdesc)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Certains champs vides ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      if(!this.form.imgpath)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Image non selectionnée", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      // Send to BE  
      this.loading.save = true;
      s = {
        pid: this.m_page_caract.pid,
        ui: this.app_uPID, 

        fn: this.form.name,
        fp: this.form.prix,
        fc: this.form.cat.code_s,
        fd: this.form.bdesc,
        fip: this.form.imgpath,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.myfoods_set, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.save = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
          // Smooth editing ...
          if(data.o == this.m_page_caract.edit )
          {
            this.list.list_shown = this.list.list_base;
            this.list.list_base.map((v,i)=>{
              if(v.id == data. plat_id)
              {
                this.list.list_base[i] = data.payload;
              }
            });
            this.f_details(data. plat_id, data.payload);
          }

          if(data.o == this.m_page_caract.create )
          {
            this.list.list_base.unshift(data.payload);
            
            this.form.name = this.form.cat = this.form.bdesc = this.form.imgpath = "";
            this.form.prix = 0;
             this.$refs.fpond_1.removeFiles();
          }

          this.list.list_shown = this.list.list_base;
          this.loading.save = false;
          ProductGlobalFunct.f_set_toast(true, " ✔ Bien, Données enregistrées" ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
        },
        (error) =>{
          this.loading.save = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
        
    },
    /** @f_get_foods_list Get Foods List */
    f_get_foods_list:function(){
      // Get Foods List   ...
      this.loading.main = true;
      s = {
        ui: this.app_uPID, 
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.myfoods_list, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.main = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          this.list.list_base = data.payload; 
          this.list.list_shown = data.payload; 
          
          this.loading.main = false;
        },
        (error) =>{
          this.loading.main = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },

    /** @f_details Select an item in list and show details @param id Id List  @param item Object   */
    f_details: function(id, item){
      this.loading.main = true;
      this.showbox.platcreatedit = false;

      // 1- Loading details data 
      this.details.food_img = item.pimg ? ProductConstant.CONST_INDEX_RESOURCE_PATH + item.pimg : '';
      this.details.food_name = item.name;
      this.details.food_price = item.price;
      this.details.food_cat = ProductConstant.CONST_PLATS_CATEGORIES.find(v=>v.code_s == item.pcat).label.fr
      this.details.food_descr = item.desc;
      this.details.food_datecreate = " Enregistré le " +  ProductGlobalFunct.f_date_toappdateformat( item.pdatecreate);

      // 2 - Loading form data 
      this.form.name = item.name;
      this.form.prix = item.price;
      this.form.cat = item.pcat;
      this.form.bdesc = item.desc;

      this.form.imgpath = item.pimg;
      this.$refs.fpond_1.removeFiles();
      this.$refs.fpond_1.addFile(this.details.food_img);

      // 3- End 
      this.loading.main = false;
      this.m_page_caract.pid = id;
   
      this.f_switcher(this.showbox._section_details);
    },
    /** @f_search Search In List   */
    f_search:function(o, evt){
      var v;
      switch (o) {
        case 1:  // Search In Foods List 
          v = evt.target.value;
          if(!v) { this.list.list_shown = this.list.list_base; return; }
          this.list.list_shown =  this.list.list_base.filter ((x)=> x.name.toLowerCase().indexOf( (v).toString().toLowerCase() ) != -1 );
          break;
      
        default:break;
      }

    },
    f_switcher:function(o){
      this.showbox.section = o;
    },
    /** @f_showbox ShowBox @param Option @param v Value  @param m Action Action  */
    f_showbox:function(o, v, m=''){
      switch (o) {
        case 1:
          this.showbox[v] = !this.showbox[v];
          break;

        case 2:
          this.form._title = this.form._title_base['_' + m];
          this.showbox[v] = !this.showbox[v];

          if(m == this.m_page_caract.create)
          {
            this.form.name = this.form.cat = this.form.bdesc = this.form.imgpath = "";
            this.form.prix = 0;
            this.$refs.fpond_1.removeFiles();
            this.m_page_caract.pid = "";
            this.list.selecteditem = "";
          }
          break;
      
        default:break;
      }
    },
  },
  components:{
    FilePond
  }
}
</script>



