<!-- ============================================================+
// File name   : Myorders.vue 
// Begin       : 15.10.21
// Last Update : 15.10.21
//  
// Description : Manage Orders for Clients & Restaurant
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
  <div class="grey lighten-4 w100 h100 pa-5">
    
    <!-- ACTION BTN  -->
    <v-row  class="animate__animated  animate__fadeIn" >
      <v-col xl="12" lg="12" md="12" sm="12" xs="12" ></v-col>
    </v-row>

    <!-- EMPTY DIVIDER  -->
    <v-row> <v-col xl="12" lg="12" md="12" sm="12" xs="12" ></v-col></v-row>

    <!-- LISTE OF ORDERS + DETAILS  -->
    <v-row>
      <v-col xl="4" lg="4" md="5" sm="5" xs="12"  v-if="(showbox.section == '1' && is_mobile) || !is_mobile ">
        <div class="white rounded pa-1  animate__animated  animate__slideInLeft" > 
          <!-- TITLE  -->
          <h4 class="text-center" >  Mes commandes </h4>
          <v-divider class="mt-3 mb-3" ></v-divider>
          
          <!-- SEARCH BAR  -->
          <v-text-field type="text"  placeholder="... Chercher un plat commandé , une commande "  v-model="list.search"  @keyup="f_search(1, $event)" v-if="list.list_base.length" ></v-text-field>
          <!-- FILTER ZONE  -->
          <div v-if="list.list_base.length" >  
            <v-chip :color="(item.v == list.filter_selected)? 'primary' : ''" v-for="item in list.filter_list" :key="item.v"  @click="f_filter(1, item.v)" class="ma-1" > {{item.n}}  </v-chip>
          </div>
        
          <!-- NO DATA YET  -->
          <div v-if="!list.list_shown.length" class="text-center pa-3 mt-3"  :style="{'min-height':list.height/2 +'px'}"  >
            La liste de vos differentes commandes  apparaitra ici
            <div align="center"  justify="center">
              <v-icon  color="primary" style="font-size:130px"> mdi-basket</v-icon>
            </div>
          </div>

          <!-- LIST  : DATA EXIST -->
          <v-list-item-group v-model="list.selecteditem" color="secondary"  :style="{'max-height':list.height+'px', 'min-height':list.height/2 +'px', 'overflow-y':'auto'}"  v-if="list.list_shown.length" class="mt-3"  >
            <v-list-item v-for="item in list.list_shown" :key="item._id"  @click="f_details(item._id, item)"  >
              <v-list-item-icon>
                <v-icon v-if="item.status == status_list.NON_VALIDE" > mdi-basket-outline  </v-icon>
                <v-icon color="primary" v-if="item.status == status_list.VALIDE" >mdi-check </v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title v-text="item.name"></v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
          
          <!-- LOAD MORE: No  -->
        </div>
      </v-col>
      <v-col xl="1" lg="1" md="1" sm="1" xs="1"  class="d-xl-block d-lg-block d-md-block d-sm-block  d-none"></v-col>
      <v-col xl="7" lg="7" md="6" sm="6" xs="12" v-if="(showbox.section == '2' && is_mobile) || !is_mobile " >
        <div class="white rounded pa-1 animate__animated  animate__slideInRight" >

           <!-- RETOUR -->
          <v-chip @click="f_switcher(showbox._section_list)" v-if="is_mobile" >
              <v-avatar left> <v-icon>mdi-chevron-left</v-icon> </v-avatar>
              Retour 
          </v-chip>

          <!-- TITLE  -->
          <h4 class="text-center" >  Details </h4>
          <v-divider class="mt-3 mb-3" ></v-divider>
          
          <!-- NO CONTENT YET  -->
          <div v-if="!m_page_caract.pid"  align="center"  justify="center" class="text-center pa-3 mt-3"  :style="{'min-height':list.height/2 +'px' }"  >
              <span> Les details de la commande apparaitront ici  </span>
               <div align="center"  justify="center">
                  <v-icon  color="secondary" style="font-size:130px"> mdi-basket</v-icon>
              </div>
          </div>

          <!-- CONTENT  -->
          <div v-if="m_page_caract.pid"  :style="{'min-height':list.height/2 +'px'}">
            
            <!-- ACTION BTN :: IF RESTAURANT -->
            <div  class="animate__animated animate__fadeIn " v-if="(this.app_uType ==  this.user_types.RESTAURANT && this.details.order_state_code == this.status_list.NON_VALIDE) "  >
              <div class="pa-1 d_flex jcfe mt-2 mb-2"  >
                <v-btn class="white--text rounded text-capitalize " color="secondary"   :loading="loading.confirm" @click="f_order_confirm()"  > Valider la commande  </v-btn>
              </div>
              <v-divider></v-divider>
            </div>

            <!-- DETAILS CONTENT -->
            <div class="pa-3 ml-5" >
                <!-- RESUME  -->
                <div class="mb-4" >
                  <v-card elevation="2"  :loading="loading.resume" class="cs">
                    <v-card-title> Resumé de la commande </v-card-title>
                      <v-card-text>
                        <p> <span class="rs">  Etat: </span>              <span class="blue--text" >  {{details.order_state | uppercase }}  </span> </p>
                        <p> <span class="rs">  Référence : </span>      <span>  {{details.order_ref}} </span> </p>
                        <p> <span class="rs">  Date : </span>           <span>  {{details.order_date}} </span> </p>
                        <p> <span class="rs">  Nombre d'articles uniques: </span>       <span>  {{details.order_nb_article}} </span> </p>
                        <p> <span class="rs">  Prix total: </span>              <span>  {{details.order_price}} {{app_devise}}  </span> </p>
                      </v-card-text>
                  </v-card>
                </div>
                <!-- DETAILS ORDER -->
                <div class="mb-4" >
                  <v-card elevation="2"  :loading="loading.resume" class="cs" >
                    <v-card-title> Details de la commande  </v-card-title>
                      <v-card-text >
                        <!-- POC ARTICLE  -->
                        <div class="mt-3" v-for="item in details.articles_list" :key="item.plat_id" >
                          <p class="font-weight-bold ma-0">  
                            <v-icon style="vertical-align:initial" > mdi-music-note-whole-dotted  </v-icon> 
                            {{item.plat_name}}  
                            </p>
                          <p class="ma-0" > {{item.nb}}  x {{ item.punit}}  </p>
                          <p class="ma-0"> {{item.price_total_article}} {{app_devise}}  </p>
                        </div>
                      </v-card-text>
                  </v-card>
                </div>
            </div>
          </div>
        </div>
      </v-col>
    </v-row>
  
    <!-- LOADING BAR  -->
    <v-progress-linear indeterminate  style="position:fixed; bottom:0.5em" v-if="loading.main"  ></v-progress-linear>

    <!-- SNACKBAR :PROCESS -->
    <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
      {{toast.msg}}
      <template v-slot:action="{ attrs }">
        <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
      </template>
    </v-snackbar>
  </div>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
.rs{ min-width:100px }
.cs { background-color:rgb(248, 248, 237) !important  }
@media screen  and (max-width:760px){
  .rs{ min-width:100px }
} 
</style>




<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'
import '@/assets/restoo.css';

// ----------- SOME GLOBAL VAR  -----------
var u_data={}, s = {};

export default {
  name: 'Myorders',
  data() {
    return {
      app_uPID:'',app_uToken:'', app_uName:'', app_uType:'',
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,
      user_types:ProductConstant.CONST_PRODUCT_APP_ROLE_LIST,
      app_devise:ProductConstant.CONST_PRODUCT_DEVISE,
      status_list : ProductConstant.CONST_PRODUCT_ORDERS_STATUS,

      m_page_caract:{ create: '0', edit: '1',   pid: ''},  // pid: Order ID 
      list :{
        search:'',   
        list_base:[],  
        list_shown:[],
        index:0,
        all:0,
        selecteditem:'', 
        height : window.screen.height - 100,
        filter_selected: '--',
        filter_list: ProductConstant.CONST_PRODUCT_ORDERS_STATUS_LIST.concat({ v: -1, n: '_TOUT_'})
      },
      showbox:{section:'1',_section_list:'1', _section_details:'2'},
      toast:{ on: false, timeout: 5000, msg: '', color:'' },
     
      details:{ order_state:'', order_state_code: '', order_ref:'', order_date: '', order_nb_article: '', order_price: '', articles_list:'', client_ref: '', item_all: ''}, 
      loading: {main: false, confirm:false },
      is_mobile : false,
    };
  },
  mounted() {
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        this.app_uPID = u_data.ui;
        this.app_uToken = u_data.utk;
        this.app_uType  = u_data.ut;
        this.app_uName = u_data.un;
    }

    this.is_mobile = ProductGlobalFunct.f_isMobile();
    this.f_orders_list();
  },
  filters:{
    capitalize: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.charAt(0).toUpperCase() + v.slice(1);
    },
    uppercase: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.toUpperCase();
    }
  },
  methods: {
    /** @f_orders_list Get Get list of Orders  */
    f_orders_list:function(){
      // Get Foods List   ...
      this.loading.main = true;
      s = {
        ui: this.app_uPID, 
        ut: this.app_uType,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.orders_list, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.main = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          var d = [];
              d = data.payload;
          d.sort((a,b)=> b.date_created-a.date_created);

          this.list.list_base = d; 
          this.list.list_shown = d; 
          
          this.loading.main = false;
        },
        (error) =>{
          this.loading.main = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },
    /** @f_order_confirm Confirm The Order : RESTAURANT */
    f_order_confirm: function(){
      // Checking  data  ...
      if(!this.app_uPID ||  !this.m_page_caract.pid)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Erreur imprevue (F:R1510211259)  ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }

      this.loading.confirm = true;
      s = {
        ui: this.app_uPID, 

        cref: this.details. client_ref,
        oitem:  this.details. item_all,
        oid: this.m_page_caract.pid,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.orders_confirm , s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.confirm = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          // Smooth editing ...
          var vo = ProductConstant.CONST_PRODUCT_ORDERS_STATUS.VALIDE;
          this.list.list_base.map((v,i)=>{
            if(v.id == data.order_id)
            {
              this.list.list_base[i].status =  vo;
            }
          });
          this.list.list_shown =  this.list.list_base;
          this.details. order_state =  ProductConstant.CONST_PRODUCT_ORDERS_STATUS_INVERSE ['_' + vo ];
          this.details. order_state_code =  ProductConstant.CONST_PRODUCT_ORDERS_STATUS_INVERSE ['_' + vo];

          this.loading.confirm = false;
          ProductGlobalFunct.f_set_toast(true, " ✔ Bien, Commande confirmée. Le client attend ses articles. Veuillez vous depecher 😊👍" ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
        },
        (error) =>{
          this.loading.confirm = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },

    /** @f_details Select an item in list and show details @param id Id List  @param item Object   */
    f_details: function(id, item){
      this.loading.main = true;

      // 1- Loading details data 
      this.details. order_state =  ProductConstant.CONST_PRODUCT_ORDERS_STATUS_INVERSE ['_' + item.status];
      this.details. order_state_code =  item.status;
      this.details. order_ref = item.name;
      this.details. order_date = ProductGlobalFunct.f_date_toappdateformat( item.date_created );
      this.details. order_nb_article = item.nb_article;
      this.details. order_price = item.price_total;

      this.details. articles_list = item.articles_list;
      

      // 2- End 
      this.loading.main = false;
      this.m_page_caract.pid = id;
      this.details. client_ref = item.ref_client;
      this.details. item_all = item;
   
      this.f_switcher(this.showbox._section_details);
    },

    /** @f_search Search In List   */
    f_search:function(o, evt){
      var v;
      switch (o) {
        case 1:  // Search In Foods List 
          v = evt.target.value;
          if(!v) { this.list.list_shown = this.list.list_base; return; }
          this.list.list_shown =  this.list.list_base.filter ((x)=> JSON.stringify(x).toLowerCase().indexOf( (v).toString().toLowerCase() ) != -1 );
          break;
      
        default:break;
      }

    },
    /** @f_filter Filter the list @param o Option @param v Filter By     */
    f_filter:function(o, v){
      switch (o) {
        case 1:  // Filter The list By  
          if(v == -1){ this.list.list_shown = this.list.list_base;  this.list.filter_selected = v; return;  }
          this.list.list_shown =  this.list.list_base.filter ((x)=> x.status == v );
          this.list.filter_selected = v;
          break;
      
        default:break;
      }

    },

    /** @f_switcher Switch ...  */
    f_switcher:function(o){
      this.showbox.section = o;
    },
    /** @f_showbox ShowBox @param Option @param v Value   */
    f_showbox:function(o, v){
      switch (o) {
        case 1: this.showbox[v] = !this.showbox[v]; break;
        default:break;
      }
    },
  }

}
</script>
