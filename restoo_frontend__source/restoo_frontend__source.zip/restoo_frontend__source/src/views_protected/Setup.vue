<!-- ============================================================+
// File name   : Setup.vue
// Begin       : 07.10.21
// Last Update : 07.10.21
//  
// Description : Setup Account 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
  <v-app>
    <v-main class="grey lighten-4 d_flex aic jcc" >

      <v-container  align-self="center"  >
        <!--  CHOOSE PROFILE : CLIENT |  RESTAURANT   -->
        <v-row align-self="center"  class="animate__animated  animate__fadeIn" >
          <v-col xl="2" lg="2" md="2" sm="1" xs="1"  class="d-xl-block d-lg-block d-md-block d-sm-block  d-none"></v-col>
          <v-col xl="8" lg="8" md="8" sm="10" xs="12" >

            <!-- TITLE -->
            <div>
              <p class="text-center  text-xl-h1 text-lg-h2 text-sm-h3 text-h4 primary--text" >  {{app_product_name}}  </p>
              <p class="text-center text-xl-h5 text-lg-h5 text-sm-h5 text-h5" > Configuration initiale de votre compte  | Choisissez votre profile  </p>
            </div>
            <v-divider></v-divider>

            <!-- CHOOSE OPTION -->
            <div class="w_100 d_flex jcsb mt-5">
              <!-- CLIENT -->
              <v-card elevation="3" class="pa-3 white cursor_p "  @click="f_choose_profile(profile_list.CLIENT)" >
                  <p class="text-xl-h2 text-lg-h2 text-sm-h3 text-h5 text-center "> Client </p>
                  <br><br>
                  <p class="grey--text text-center  mt-5" >  Avec ce compte, vous pourriez faire des commandes sur la plateforme </p>
                  <div class="text-center"  v-if="profile.chosen == profile_list.CLIENT">
                     <v-icon  class="text-xl-h1 text-lg-h1 text-sm-h1 text-h2 " :color="(profile.chosen == profile_list.CLIENT) ?   'primary':'' ">mdi-check</v-icon>
                  </div>
                  <br>
              </v-card>

              <!-- RESTAURANT -->
              <v-card elevation="3" class="pa-3 white cursor_p "    @click="f_choose_profile(profile_list.RESTAURANT)"  >
                  <p class="text-xl-h2 text-lg-h2 text-sm-h3 text-h5 text-center "> Restaurant </p>
                  <br><br>
                  <p class="grey--text text-center  mt-5" >  Avec ce compte, vous pourriez diffuser vos plats sur la plateforme </p>
                  <div class="text-center" v-if="profile.chosen == profile_list.RESTAURANT" >
                     <v-icon  class="text-xl-h1 text-lg-h1 text-sm-h1 text-h2 " :color="(profile.chosen == profile_list.RESTAURANT) ?   'primary':''">mdi-check</v-icon>
                  </div>
                  <br>
              </v-card>
            </div>
           
            <!-- SUBMIT BTN  -->
            <div class="mt-5  mb-2 w100" >
                <v-btn large   elevation="2" color="primary"  :loading="loading.process"  @click="f_save_profile()" class="w100 text-center" > Enregistrer  </v-btn>
            </div>

          </v-col>
          <v-col xl="2" lg="2" md="2" sm="1" xs="1"  class="d-xl-block d-lg-block d-md-block d-sm-block d-none"></v-col>
        </v-row>

        <!-- SNACKBAR :PROCESS -->
        <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
          {{toast.msg}}

          <template v-slot:action="{ attrs }">
            <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
          </template>

        </v-snackbar>
      </v-container>
        
    </v-main>
  </v-app>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
  .v-card{ min-height:300px !important; max-width:45%;  }

</style>


<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'
import '@/assets/restoo.css';

// ----------- SOME GLOBAL VAR  -----------
var s = {}, u_data={};
var app_uPID = "",app_uToken = "", app_uName = "";

export default {
  name: 'Setup',
  data() {
    return {
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,
      profile_list: ProductConstant.CONST_PRODUCT_APP_ROLE_LIST,
      profile:{ chosen:0},
      loading:{ process:false},
      showbow:{},
      toast:{ on: false, timeout: 5000, msg: '', color:'' },
    };
  },
  mounted() {
    // Get Params If Exist : Switch to session
    // var p = this.$route.params.o;
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        app_uPID = u_data.ui;
        app_uToken = u_data.utk;
        app_uName = u_data.un;
    }
    // TODO:LATER Block If 1st Config Alreday Done 
  },
  methods: {
    /** @f_save_profile  Save User Profile : */
    f_save_profile:function(){
      // Checking  data  ...
      if(!app_uPID || !app_uToken )
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Erreur imprevue (R0710211511)", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      if(!this.profile.chosen)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Pas de profile choisi (R0710211512)", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      // Send to BE  
      this.loading.process = true;
      s = {
        ui: app_uPID, 
        ut: this.profile.chosen,
        un: app_uName, 
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: app_uToken,
        _ui: app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.config_init_set, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.process = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          // SUCCESS : Update Local Var + Redirect 
          u_data.ut = data.ut; 
          u_data = JSON.stringify(u_data);
          var ciphertext = ProductGlobalFunct.f_aes_encrypt(u_data, 'HEX');
          localStorage.setItem( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT, ciphertext);

          var account_url = ProductConstant.CONST_PAGE_URL_LIST.myorders.path;
          // if(data.ut  == ProductConstant.CONST_PRODUCT_APP_ROLE_LIST.RESTAURANT) { account_url = ProductConstant.CONST_PAGE_URL_LIST.rhome.path;}
          // if(data.ut  == ProductConstant.CONST_PRODUCT_APP_ROLE_LIST.CLIENT){ account_url = ProductConstant.CONST_PAGE_URL_LIST.chome.path;}
          this.loading.process = false;
          ProductGlobalFunct.f_goto(1, account_url, this);
        },
        (error) =>{
           this.loading.process = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },
    /** @f_choose_profile  Choose Profile  */
    f_choose_profile:function(o){
      this.profile.chosen = o;
    },
  },
}
</script>



