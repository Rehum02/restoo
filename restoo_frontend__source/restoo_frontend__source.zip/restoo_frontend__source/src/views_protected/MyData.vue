<!-- ============================================================+
// File name   : MyData.vue
// Begin       : 15.10.21
// Last Update : 15.10.21
//  
// Description : My Private Data
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
  <div class="grey lighten-4 w100 h100 pa-5">
    
    <!-- ACTION BTN  -->
    <v-row  class="animate__animated  animate__fadeIn" >
      <v-col xl="12" lg="12" md="12" sm="12" xs="12" ></v-col>
    </v-row>

    <!-- EMPTY DIVIDER  -->
    <!-- <v-row> <v-col xl="12" lg="12" md="12" sm="12" xs="12" ></v-col></v-row> -->

    <!-- PRIVATE DATA   -->
    <v-row>
      <v-col xl="3" lg="3" md="3" sm="3" xs="1" ></v-col> 
      <v-col xl="6" lg="6" md="6" sm="6" xs="10">
        <!-- CARD PRIVATE DATA: RESTAU + CLIENT  -->
        <v-card class="white animate__animated  animate__slideInRight mt-5" elevation="2">
          <div>
            <v-expansion-panels focusable>
              <v-expansion-panel>
                <v-expansion-panel-header>  <v-card-title>  Mes données personnelles </v-card-title> </v-expansion-panel-header>
                <v-expansion-panel-content>
                  <v-list> 
                    <!-- NOM  -->
                    <v-list-item>
                      <v-list-item-content>
                        <v-text-field type="text"  placeholder="..."  label="Votre nom et prenom(s)" v-model="form.uname" ></v-text-field>
                      </v-list-item-content>
                    </v-list-item>

                    <!-- EMAIL  -->
                    <v-list-item>
                      <v-list-item-content>
                        <v-text-field type="email"  placeholder="..."  label="Votre email " v-model="form.umail" ></v-text-field>
                      </v-list-item-content>
                    </v-list-item>

                    <!-- ADRESSE  -->
                    <v-list-item>
                      <v-list-item-content>
                        <v-text-field type="text"  placeholder="..."  label="Votre adresse " v-model="form.uadresse" ></v-text-field>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list>
                </v-expansion-panel-content>
              </v-expansion-panel>
            </v-expansion-panels>
          </div>
          <v-card-actions>
              <div class="w100 animate__animated  animate__fadeInUp  d_flex jcfe ">
                <v-btn class="text-center" color="secondary"  :loading="loading.form_pdata" @click="f_data_set(1)" > Enregistrer </v-btn>
              </div>
          </v-card-actions>
        </v-card>

        <!-- CARD : RESTAU NAME   -->
        <v-card class="white animate__animated  animate__slideInRight mt-5" elevation="2" v-if="app_uType == user_types.RESTAURANT" >
          <div>
            <v-expansion-panels focusable>
              <v-expansion-panel>
                <v-expansion-panel-header>  <v-card-title>  Mon Restaurant </v-card-title> </v-expansion-panel-header>
                <v-expansion-panel-content>
                    <v-list> 
                        <!-- NOM RESTAU  -->
                        <v-list-item>
                        <v-list-item-content>
                            <v-text-field type="text"  placeholder="..."  label="Nom de mon restaurant" v-model="form.restau_name" ></v-text-field>
                        </v-list-item-content>
                        </v-list-item>
                        <!-- LOCALISATION  -->
                        <v-list-item>
                        <v-list-item-content>
                            <v-text-field type="text"  placeholder="..."  label="Localisation du restaurant" v-model="form.restau_location" ></v-text-field>
                        </v-list-item-content>
                        </v-list-item>
                    </v-list>
                </v-expansion-panel-content>
              </v-expansion-panel>
            </v-expansion-panels>
          </div>
          <v-card-actions>
              <div class="w100 animate__animated  animate__fadeInUp  d_flex jcfe ">
                <v-btn class="text-center" color="secondary"  :loading="loading.form_prestau" @click="f_data_set(2)" > Enregistrer </v-btn>
              </div>
          </v-card-actions>
        </v-card>

        <!-- CARD PASS   -->
        <v-card class="white animate__animated  animate__slideInRight mt-5 mb-5" elevation="2">
          <div>
            <v-expansion-panels focusable>
              <v-expansion-panel>
                <v-expansion-panel-header>  <v-card-title>  Mot de passe </v-card-title> </v-expansion-panel-header>
                <v-expansion-panel-content>
                     <v-list> 
                        <!-- PASSWORD 1   -->
                        <v-list-item>
                        <v-list-item-content>
                            <v-text-field type="password"  placeholder="..."  label="Mot de passe" v-model="form.upass_1"  hint="Le mot de passe doit être au moins 8 caractères et contenir des caratères aphanumeriques et des symboles " persistent-hint  ></v-text-field>
                        </v-list-item-content>
                        </v-list-item>
                        <!-- PASSWORD 2  -->
                        <v-list-item>
                        <v-list-item-content>
                            <v-text-field type="password"  placeholder="..."  label="Répetez le mot de passe" v-model="form.upass_2" ></v-text-field>
                        </v-list-item-content>
                        </v-list-item>
                    </v-list>
                </v-expansion-panel-content>
              </v-expansion-panel>
            </v-expansion-panels>
          </div>
          <v-card-actions>
              <div class="w100 animate__animated  animate__fadeInUp  d_flex jcfe ">
                <v-btn class="text-center" color="secondary"  :loading="loading.form_ppass" @click="f_data_set(3)" > Enregistrer </v-btn>
              </div>
          </v-card-actions>
        </v-card>

      </v-col>
    </v-row>
  
    <!-- LOADING BAR  -->
    <v-progress-linear indeterminate  style="position:fixed; bottom:0.5em" v-if="loading.main"  ></v-progress-linear>

    <!-- SNACKBAR :PROCESS -->
    <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
      {{toast.msg}}
      <template v-slot:action="{ attrs }">
        <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
      </template>
    </v-snackbar>

  </div>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
@media screen  and (max-width:760px){} 
</style>




<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'
import '@/assets/restoo.css';

// ----------- SOME GLOBAL VAR  -----------
var u_data={}, s = {};

export default {
  name: 'MyData',
  data() {
    return {
      app_uPID:'',app_uToken:'', app_uName:'', app_uType:'',
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,
      user_types:ProductConstant.CONST_PRODUCT_APP_ROLE_LIST,
      app_devise:ProductConstant.CONST_PRODUCT_DEVISE,
      status_list : ProductConstant.CONST_PRODUCT_ORDERS_STATUS,
      form : {uname:'',umail:'', uadresse: '',    restau_name:'',restau_location:'', upass_1:'', upass_2:'' },
      m_page_caract:{ create: '0', edit: '1',   pid: ''},  // pid: Order ID 
      showbox:{section:'1',_section_list:'1', _section_details:'2'},
      toast:{ on: false, timeout: 5000, msg: '', color:'' },
      loading: {main: false, confirm:false },
      is_mobile : false
    };
  },
  mounted() {
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        this.app_uPID = u_data.ui;
        this.app_uToken = u_data.utk;
        this.app_uType  = u_data.ut;
        this.app_uName = u_data.un;
    }

    this.is_mobile = ProductGlobalFunct.f_isMobile();
    this.f_data_get();
  },
  filters:{
    capitalize: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.charAt(0).toUpperCase() + v.slice(1);
    },
    uppercase: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.toUpperCase();
    }
  },
  methods: {
    /** @f_data_get Get User data */
    f_data_get:function(){
      this.loading.main = true;
      s = {
        ui: this.app_uPID, 
        ut: this.app_uType,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.mydata_get, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.main = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          // Private data 
          this.form.uname = data.uname;   
          this.form.umail = data.umail;
          this.form.uadresse = data.uadress;

          // Restau data
          this.form.restau_name = data.restau_name;
          this.form.restau_location = data.restau_location;

          this.loading.main = false;    
        },
        (error) =>{
          this.loading.main = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },

    /** @f_data_set Set User data  */
    f_data_set: function(o){
      // Checking  data  ...
      switch (o) {
        case 1: // PRIVATE DATA 
            if(!this.form.uname || !this.form.umail ||  !this.form.uadresse)
            {
              ProductGlobalFunct.f_set_toast(true, "Ooops, Certains champs vides : Section données personnelles ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
              return;
            }
            if( !ProductConstant.CONST_EMAIL_FORMAT.test( this.form.umail))
            {
              ProductGlobalFunct.f_set_toast(true, "Ooops, Le format de l'email semble être incorrect", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
              return;
            }
            this.loading.form_pdata = true;
          break;

        case 2: // RESTAU NAME 
          if(!this.form.restau_name || !this.form.restau_location)
          {
            ProductGlobalFunct.f_set_toast(true, "Ooops, Certains champs vides : Section Restaurant  ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
           this.loading.form_prestau = true;
          break;

        case 3: // PASSWORD
          if(!this.form.upass_1 || !this.form.upass_1)
          {
            ProductGlobalFunct.f_set_toast(true, "Ooops, Certains champs vides : Section Mot de passe  ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
          if(this.form.upass_1 != this.form.upass_2)
          {
            ProductGlobalFunct.f_set_toast(true, "Ooops, Mots de passe non identiques  ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
          var p = ProductGlobalFunct.f_check_pass_strength(this.form.upass_1);
          if(!p)
          {
            ProductGlobalFunct.f_set_toast(true, "Ooops, Le mot de passe ne repond pas aux exigences", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
          this.loading.form_ppass = true;
          break;
      
        default:break;
      }

      // Send to BE  
      s = {
        ui: this.app_uPID, 
        o: o,

        un: this.form.uname,
        um: this.form.umail,
        ua: this.form.uadresse,
        
        ur: this.form.restau_name,
        ul: this.form.restau_location,

        up: this.form.upass_1,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.mydata_set, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.form_pdata = false;
            this.loading.form_prestau = false;
            this.loading.form_ppass = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          this.loading.form_pdata = false;
          this.loading.form_prestau = false;
          this.loading.form_ppass = false;

          this.form.upass_1 = this.form.upass_2 = "";

          ProductGlobalFunct.f_set_toast(true, " Bien, Données enregistrées 😊👍 " ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
        },
        (error) =>{
          this.loading.form_pdata = false;
          this.loading.form_prestau = false;
          this.loading.form_ppass = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },

    /** @f_switcher Switch ...  */
    f_switcher:function(o){
      this.showbox.section = o;
    },
    /** @f_showbox ShowBox @param Option @param v Value   */
    f_showbox:function(o, v){
      switch (o) {
        case 1: this.showbox[v] = !this.showbox[v]; break;
        default:break;
      }
    },
  }

}
</script>
