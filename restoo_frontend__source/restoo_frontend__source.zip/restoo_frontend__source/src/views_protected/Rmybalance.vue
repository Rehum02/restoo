<!-- ============================================================+
// File name   : Rmybalance.vue
// Begin       : 15.10.21
// Last Update : 15.10.21
//  
// Description : Balance 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
  <div class="grey lighten-4 w100 h100 pa-5">
    
    <!-- ACTION BTN  -->
    <v-row  class="animate__animated  animate__fadeIn" >
      <v-col xl="12" lg="12" md="12" sm="12" xs="12" ></v-col>
    </v-row>

    <!-- EMPTY DIVIDER  -->
    <!-- <v-row> <v-col xl="12" lg="12" md="12" sm="12" xs="12" ></v-col></v-row> -->

    <!-- BALANCE TOTAL + REVENU / PLAT  -->
    <v-row>
      <v-col xl="5" lg="5" md="5" sm="5" xs="12">
          <v-card elevation="2"  class="rmb white animate__animated  animate__slideInRight" >
            <v-card-title> Ma Balance financière</v-card-title>
            <div class="b d_flex aic jcc">
                <p class="text-center  text-xl-h1 text-lg-h2 text-sm-h3 text-h4 primary--text" > {{balance.all_balance}} {{app_devise}}  </p>
            </div>
          </v-card>
      </v-col>
      <v-col xl="2" lg="2" md="2" sm="2" xs="1" class="d-xl-block d-lg-block d-md-block d-sm-block  d-none"> </v-col>
      <v-col xl="5" lg="5" md="5" sm="5" xs="12">
        <v-card elevation="2" class="rmb white animate__animated  animate__slideInRight"  >
          <v-card-title> Revenu par plat</v-card-title>
          <div class="b" >
            <canvas class="canvas_revenuplat" ></canvas>
          </div>
          </v-card>
      </v-col>
    </v-row>

    <!-- VOLUME DE COMMANDE DE CHAQUE PLAT   -->
    <br><br><br>
    <v-row>
      <v-col xl="12" lg="12" md="12" sm="12" xs="12">
          <v-card elevation="2"  class="rmb_h white animate__animated  animate__slideInRight " >
            <v-card-title> Volume de commande par plat </v-card-title>
            <v-card-text>
              <canvas class="canvas_volumeplat"  ></canvas>
            </v-card-text>
          </v-card>
      </v-col>
    </v-row>
  
    <!-- LOADING BAR  -->
    <v-progress-linear indeterminate  style="position:fixed; bottom:0.5em" v-if="loading.main"  ></v-progress-linear>

    <!-- SNACKBAR :PROCESS -->
    <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
      {{toast.msg}}
      <template v-slot:action="{ attrs }">
        <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
      </template>
    </v-snackbar>

  </div>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
.rmb{ min-height: 200px; }
.rmb_h{ min-height: 250px; }
.canvas_revenuplat{ max-height:200px; }
.canvas_volumeplat{ max-height:500px; }
.b{min-height:250px; }
@media screen  and (max-width:760px){} 
</style>




<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'
import '@/assets/restoo.css';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);


// ----------- SOME GLOBAL VAR  -----------
var u_data={}, s = {};

export default {
  name: 'Rmybalance',
  data() {
    return {
      app_uPID:'',app_uToken:'', app_uName:'', app_uType:'',
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,
      user_types:ProductConstant.CONST_PRODUCT_APP_ROLE_LIST,
      app_devise:ProductConstant.CONST_PRODUCT_DEVISE,
      status_list : ProductConstant.CONST_PRODUCT_ORDERS_STATUS,

      m_page_caract:{ create: '0', edit: '1',   pid: ''},  // pid: Order ID 
      list :{
        search:'',   
        list_base:[],  
        list_shown:[],
        index:0,
        all:0,
        selecteditem:'', 
        height : window.screen.height - 100,
        filter_selected: '--',
        filter_list: ProductConstant.CONST_PRODUCT_ORDERS_STATUS_LIST.concat({ v: -1, n: '_TOUT_'})
      },
      showbox:{section:'1',_section_list:'1', _section_details:'2'},
      toast:{ on: false, timeout: 5000, msg: '', color:'' },
      balance:{all_balance:'-'},
      loading: {main: false, confirm:false },
      is_mobile : false,
    };
  },
  mounted() {
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        this.app_uPID = u_data.ui;
        this.app_uToken = u_data.utk;
        this.app_uType  = u_data.ut;
        this.app_uName = u_data.un;
    }

    this.is_mobile = ProductGlobalFunct.f_isMobile();
    this.f_orders_list();
  },
  filters:{
    capitalize: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.charAt(0).toUpperCase() + v.slice(1);
    },
    uppercase: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.toUpperCase();
    }
  },
  methods: {
    /** @f_orders_list Get Get list of Orders  For Restaurant */
    f_orders_list:function(){
      // Get Foods List   ...
      this.loading.main = true;
      s = {
        ui: this.app_uPID, 
        ut: this.app_uType,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.orders_list, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.main = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          // ---- Compute data for chart ------------------------
          var d = [];   d = data.payload;   
          this.balance.all_balance  = 0;
          var a = 0;     // all balance 
          var p = {};   // { plat_id: {_count:0, _revenue:0, name: 0 }}
          var ak = [];  // all key 
          d.map((v)=>{
            // 1 - Build All Balance 
            a+= v.price_total;

            // 2 - Build Income per Food  + Volume per food 
            v.articles_list.forEach((y)=>{
              if( p[y.plat_id])
              {
                 p[y.plat_id]['_count'] += 1;
                 p[y.plat_id]['_revenue'] = p[y.plat_id]['_revenue'] + y.price_total_article;
              } else {
                p[y.plat_id] = 
                {
                    _count:1,
                    _revenue: y.price_total_article,
                    name: y.plat_name 
                };
                ak.push(y.plat_id);
              }
            });
          });
          this.balance.all_balance = a;
          var all_labels = [], all_revenue = [], all_count = [], color_list = [];
          var c;
          ak.forEach(v=>{
              all_labels.push( p[v].name);
              all_revenue.push( p[v]._revenue);
              all_count.push( p[v]._count);
              c =  ProductGlobalFunct.f_generate_color();
              color_list.push( c );
          });

          // Build Chart : All Income 
          var pie_data =
          {
            labels: all_labels,
            datasets:[{label:'Revenue par plat', backgroundColor:color_list,  data: all_revenue,  hoverOffset: 4 }]
          };
          var options = {};
          this.f_build_chart('.canvas_revenuplat', 'pie', pie_data, options )

          // Build Chart : Revenue per foods 
          var hist_data =
          {
            labels: all_labels,
            datasets:[{label: 'Volume de commande par plat', backgroundColor:color_list,  data: all_count}]
          };
          this.f_build_chart('.canvas_volumeplat', 'bar', hist_data, {} )

          this.loading.main = false;
        },
        (error) =>{
          this.loading.main = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },

    /** @f_build_chart Build  Chart @param el Dom Element  @param ct ChartType @param cd Chart Data  {label, dataset} @param co Chart Options  */
    f_build_chart:function(el, ct, cd, co={}){
      var  chartElement = document.querySelector(el);
      var o = co? { type: ct,data: cd,options: co} : { type: ct,data: cd}
      new Chart(chartElement, o);
    },
    /** @f_switcher Switch ...  */
    f_switcher:function(o){
      this.showbox.section = o;
    },
    /** @f_showbox ShowBox @param Option @param v Value   */
    f_showbox:function(o, v){
      switch (o) {
        case 1: this.showbox[v] = !this.showbox[v]; break;
        default:break;
      }
    },
  }

}
</script>
