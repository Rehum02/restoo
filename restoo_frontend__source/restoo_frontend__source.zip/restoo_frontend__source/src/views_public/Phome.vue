<!-- ============================================================+
// File name   : Phome.vue 
// Begin       : 16.10.21
// Last Update : 16.10.21
//  
// Description : HomePage 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
   <v-app>
      <!-- HEADER:  lg>  -->
      <v-toolbar color="primary" dark class="d-xl-block d-lg-block d-md-block d-sm-block  d-none" style="min-height:5.5em" >
        <v-toolbar-title class="ml-2 text-xl-h4 text-lg-h4 text-sm-h4 text-h4  " > {{app_product_name}} </v-toolbar-title>
        <v-spacer></v-spacer>
        <span @click="f_goto_local(1, '.pl_list')"  class="cursor_p"  >  <v-icon small >mdi-basket</v-icon>  {{text.btn_list_p | capitalize }} </span>
        <span v-if="!app_uPID" >
          <span @click="f_goto_local(2, null, m_link.auth)" class="cursor_p"  style="margin-left:4em" >  <v-icon small>mdi-login</v-icon>  {{text.btn_c | capitalize }}  </span>
          <span @click="f_goto_local(2, null, m_link.auth)" class=" cursor_p" style="margin-left:1em">   | {{ text.btn_o | capitalize }}  </span>
        </span>
        <span  v-if="app_uPID" @click="f_goto_local(2, null, m_link.m_account)" class=" cursor_p" style="margin-left:1em">  <v-icon  small> mdi-account-circle-outline </v-icon>  {{ text.btn_ma | capitalize }}  </span>
      </v-toolbar>
      <!-- HEADER   <lg -->
      <v-toolbar color="primary" dark class="d-xl-none d-lg-none d-md-none d-sm-none  d-block"  style="min-height:4.5em">
        <v-toolbar-title class="ml-2 text-xl-h4 text-lg-h4 text-sm-h4 text-h4" > {{app_product_name}} </v-toolbar-title>
        <v-spacer></v-spacer>

        <span  v-if="showbox.mobilemenu" class="animate__animated animate__fadeIn" >  
          <small @click="f_goto_local(1, '.pl_list')"  class="cursor_p"  >  <v-icon small >mdi-basket</v-icon>  {{text.btn_list_p | capitalize }} </small>
          <span v-if="!app_uPID" >
            <small @click="f_goto_local(2, null, m_link.auth)" class="cursor_p"  style="margin-left:4em" >  <v-icon small>mdi-login</v-icon>  {{text.btn_c | capitalize }}  </small>
            <small @click="f_goto_local(2, null, m_link.auth)" class=" cursor_p" style="margin-left:1em">   | {{ text.btn_o | capitalize }}  </small>
          </span>
          <small  v-if="app_uPID" @click="f_goto_local(2, null, m_link.m_account)" class=" cursor_p" style="margin-left:1em">  <v-icon  small> mdi-account-circle-outline </v-icon>  {{ text.btn_ma | capitalize }}  </small>
        </span>

        <v-icon class="white--text cursor_p" right  @click="f_showbox(1, 'mobilemenu')" >mdi-menu</v-icon>
      </v-toolbar>

      <!-- BODY -->
      <v-main>
        <v-container fluid style="padding:0" >
          
          <div>

            <v-row style="height:7px" >
              <v-col xl="12" lg="12" md="12" sm="12" xs="12" class="grey lighten-3 w100"  ></v-col>    
            </v-row> 

            <!-- BANNER  -->
            <v-row class="h80" >    
              <v-col xl="8" lg="8" md="8" sm="8" xs="12"  class="app_bg_color" >
                <div class="pa-4">
                  <div style="margin-top:3em" ></div>
                  <div class="text-xl-h2 text-lg-h2 text-sm-h2 text-h3 white--text"> Vos plats preférés proches de vous </div>

                  <div style="margin-top:2em" ></div>
                  <div class="text-xl-h4 text-lg-h4 text-sm-h4 text-h4 white--text"> Commandez, vous êtes livrés </div>

                  <div style="margin-top:3em" ></div>
                  <!-- <v-btn medium elevation="2" color="secondary"   >  </v-btn> -->
                  <v-chip large color="secondary" @click="f_goto_local(1, '.pl_list')" class="pa-5"  > Commander un plat  </v-chip>
                  <v-chip large color="secondary" @click="f_goto_local(2, null, m_link.auth)" class="ml-2 pa-5"  > Créer mon compte  </v-chip>
                </div>
              </v-col>
              <v-col xl="4" lg="4" md="4" sm="4" xs="12" class="app_bg_color">
                <div class="pa-4" >   
                  <v-carousel cycle height="450"  hide-delimiter-background show-arrows-on-hover class="d_flex aic jcc"  >
                      <v-carousel-item   v-for="slide in slides" :key="slide.id"  transition="fade-transition" >
                            <v-img :src="slide.i" style="min-height:300px; border-radius:50%" ></v-img>
                            <p class="text-center mt-3 white--text  text-xl-h4 text-lg-h4 text-sm-h4 text-h4 " > {{slide.n}}  </p>
                      </v-carousel-item>
                  </v-carousel>
                </div>
              </v-col>
            </v-row>

            <!-- CATEGORY OF FODD  -->
            <v-row style="margin-top:3em"> 
              <v-col xl="12" lg="12" md="12" sm="12" xs="12" >
                <h1 class="text-center mb-3" > - Differentes catégories de plat - </h1>

                <v-card  elevation="2" v-for="(item, index) in categories_list" :key="index" @click="f_filter(1, item.code_s)"  :style="{'border': '1px solid ' + bgcolor_list[index]}"  class="rounded c cursor_p"  >
                  <div class="w100 h100 d_flex aic jcc pa-1" >
                    <span class="text-xl-h4 text-lg-h4 text-sm-h4 text-h4" :style="{'font-weight': (list.filter_selected == item.code_s ) ? 'bolder': 'normal'}"> {{item.label.fr}} </span>
                  </div>
                </v-card>
              </v-col>
            </v-row>

            <!-- LISTE DES RESTAURANTS + SEARCH -->
            <v-row style="min-height:250px; margin-top:3em" class="d_flex aic jcc  grey lighten-4"  > 
              <v-col xl="11" lg="11" md="11" sm="11" xs="11" class="pa-1">

                <h1 class="text-center mb-3" style="margin-top:2em" > - Plusieurs restaurants - </h1>

                <!-- CHEAP LIST -->
                <v-sheet  class="py-2 px-1 mt-3" color="transparent"  >
                  <v-chip-group active-class="primary--text" >
                      <v-chip large  v-for="r in list.restau" :key="r.id" @click="f_filter(2, r.id)" > {{ r.rn }} </v-chip>
                  </v-chip-group>
                </v-sheet>

                <!-- SEARCH -->
                <v-list color="transparent" > 
                      <v-list-item>
                        <v-list-item-content>
                          <v-text-field type="text"  placeholder=" Chercher un plat dans la liste ..."   @keyup="f_search(1, $event)" ></v-text-field>
                        </v-list-item-content>
                      </v-list-item>
                </v-list>
              </v-col>
            </v-row>
          
            <!-- LIST OF FIELD -->
            <v-row> 
              <v-col xl="12" lg="12" md="12" sm="12" xs="12" align="center" justify="center" class="pl_list"  >
                  <!-- LOADING  -->
                  <v-progress-circular size="100" width="10" color="primary" indeterminate v-if="loading.list" ></v-progress-circular>

                  <!-- LIST  -->
                  <v-card class="pc" v-for="item in list.list_shown" :key="item.id"  >
                    <v-img height="250" :lazy-src="item.pimg"></v-img>

                    <v-card-title> {{item.name}} </v-card-title>

                    <div class="text-left">
                      <div class="text-subtitle-1 ml-1"> {{item.price}}  {{app_devise}}  </div>
                      <div class="ml-1 grey grey--text lighten-3"> Par {{ item.rname }} </div>

                      <div class="mt-2" >
                        <v-expansion-panels>
                          <v-expansion-panel>
                            <v-expansion-panel-header  class="grey--text lighten-3" style="padding: 0.5em !important" > {{ item.desc_short }} </v-expansion-panel-header>
                            <v-expansion-panel-content >
                              {{ item.desc }}
                            </v-expansion-panel-content>
                          </v-expansion-panel>
                        </v-expansion-panels>
                      </div>
                    </div>

                    <v-divider class="ma-1"></v-divider>

                    <v-card-actions>
                      <v-btn class="w100 cb text-center"  style="border-radius:3em" color="primary" @click="f_add_cart(item.id,  item)" >
                        <span> Commander </span>
                      </v-btn>
                    </v-card-actions>
                  </v-card>
              </v-col>
            </v-row>
            <v-row v-if="!list.list_shown.length"> 
              <v-col xl="12" lg="12" md="12" sm="12" xs="12" class="text-center"  >
                <h2 class="font-weight-normal" > La liste des plats correspondants s'affichera ici </h2>
              </v-col> 
            </v-row> 
        

            <!-- LOAD MORE :TODO:LATER  -->

            <!-- PRODUCT NAME  -->
            <v-row style="margin-top:4em; margin-bottom:2em "> 
              <v-col xl="12" lg="12" md="12" sm="12" xs="12" align="center" justify="center" >
                <div style="font-family: 'emoji !important'" >
                    <v-divider></v-divider>
                    <br>
                    <p class="ml-2 text-xl-h2 text-lg-h2 text-sm-h2 text-h3  blue--text" > {{app_product_name}}, humm trop bon 😋 </p>
                    <br>
                    <v-divider></v-divider>
                </div>
              </v-col>
            </v-row>

            <!-- CART  -->
              <!-- <v-fab-transition  :style="{'z-index': showbox.article_list ?  -1: 10000}" > -->
            <v-fab-transition>
                    <v-btn x-large v-if="cart_article_list.length" color="secondary" dark fixed bottom right fab   class="animate__animated animate__fadeIn animate__infinite" @click="f_showbox(1, 'article_list')"  >
                      <h2> + {{cart_article_list.length}}  </h2>
                    </v-btn>
            </v-fab-transition>

            <!-- DRAWER : LISTE DES ARTICLES   -->
            <v-navigation-drawer fixed temporary right v-model="showbox.article_list"  class="d_flex dr "  style="flex-direction: column;"   >
                <!-- BODY -->
                <div>
                    <!-- HEADER -->
                    <v-list-item>
                        <v-list-item-avatar  @click="f_showbox(1, 'article_list')"  class="cursor_p" >
                          <v-icon> mdi-menu </v-icon>
                        </v-list-item-avatar>
                        <v-list-item-content>
                          <v-list-item-title class="text-center" >
                            <p class="text-xl-h5 text-lg-h5 text-sm-h5 text-h5 ">  Details de la commande </p>
                          </v-list-item-title>  
                        </v-list-item-content>
                    </v-list-item>
                
                    <v-divider></v-divider>
                
                    <!-- RESUME  -->
                    <v-card elevation="2" class="cs mt-2">
                      <v-card-title> Resumé de la commande </v-card-title>
                        <v-card-text>
                          <p> <span class="rs">  Nombre d'articles uniques: </span>       <span>  {{cart.order_nb_article}} </span> </p>
                          <p> <span class="rs">  Prix total: </span>              <span>  {{cart.order_price}} {{app_devise}}  </span> </p>
                        </v-card-text>
                    </v-card>

                    <!-- ARTICLES : LIST   -->
                    <v-card elevation="2" class="cs mt-4" >
                      <v-card-title> Details de la commande  </v-card-title>
                      <v-card-text>
                        <!-- PLAT NAME :  QTE *  PRICE UNIT * TOTAL PARTIEL  -->
                        <div class="mt-5 w100" v-for="item in cart_article_list" :key="item.plat_id" >
                            <p class="font-weight-bold ma-0">  
                              <v-icon style="vertical-align:initial" > mdi-music-note-whole-dotted  </v-icon> 
                              {{item.plat_name}} 

                              <v-icon class="red--text" style="float:right" @click="f_cart_remove(item.plat_id)" > mdi-close </v-icon>
                            </p>
                            <div class="ma-0">
                              <v-text-field  style="width:35%; height:20px; margin:0; padding:0; font-size:0.9em"  single-line small   :value="item.nb"  min="1" @keyup="f_cart_updateq(item.plat_id, $event)" :suffix=" ' x ' + item.punit +' '  + app_devise" ></v-text-field> 
                            </div>
                            <p class="mt-3"> {{item.price_total_article}} {{app_devise}}  </p>
                        </div> 
                      </v-card-text>
                    </v-card>
                </div>

                <!-- ACTION BTN  -->
                <div class="w100 animate__animated  animate__fadeInRight  mt-4" v-if="showbox.confirm_order" >
                    <v-btn class="text-center w100" color="primary"  :loading="loading.save" @click="f_make_order()" > Valider </v-btn>
                </div>
                <div class="mt-auto  w100 animate__animated  animate__fadeInUp">
                    <v-btn class="text-center w100 mt-5 " color="secondary" @click="f_showbox(1, 'confirm_order')" > Faire la commande </v-btn>
                </div>
            </v-navigation-drawer>

            <!-- SNACKBAR :PROCESS -->
            <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
              {{toast.msg}}
              <template v-slot:action="{ attrs }">
                <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
              </template>
            </v-snackbar>
          </div>
          
        </v-container>
      </v-main>

      <!-- FOOTER -->
      <v-footer dark padless>
        <v-card flat tile class="indigo lighten-1 white--text text-center w100" >
          <v-card-text>
            <v-btn v-for="icon in icons" :key="icon" class="mx-4 white--text" icon>
              <v-icon size="24px">
                {{ icon }}
              </v-icon>
            </v-btn>
          </v-card-text>

          <v-card-text class="white--text pt-0"> Vos plats preférés proches de vous. Plats africains, européens, asiatiques, americains. Commandez, vous êtes livrés </v-card-text>
          <v-divider></v-divider>

          <v-card-text class="white--text" style="margin-top:2em" >
            {{ new Date().getFullYear() }} — <strong> {{app_product_name}} </strong>
          </v-card-text>

          <v-card-text class="yellow--text lighten-5">
            <small>  By Miché KOKORA  </small>
          </v-card-text>
        </v-card>
      </v-footer>
  </v-app>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
.c{ min-width:300px; max-width:300px; height:140px; margin:1em; display:inline-block }
.dr{ min-width: 400px;  }
.h80{height:80%;}
.h80v{height:80vh;}
.w30{width:30%}
.w60{width:60%}
.cs { background-color:rgb(248, 248, 237) !important  }
.pc { margin:1em; max-width:300px; display:inline-block; min-height:450px;  }
.cb .v-chip__content{width:100% !important}
.v-chip__content{ width:100% !important}
@media screen  and (max-width:760px){
    .dr{ width:80%}
    .c{ min-width:200px; max-width:200px; height:100px; margin:0.5em }
    .pc { margin:1em; max-width:40%;  }
} 
</style>




<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'
import '@/assets/restoo.css';

// ----------- SOME GLOBAL VAR  -----------
var u_data={}, s = {};

export default {
  name: 'Phome',
  data() {
    return {
      app_uPID:'',app_uToken:'', app_uName:'', app_uType:'',
      app_product_name: ProductConstant.CONST_PRODUCT_NAME,
      user_types:ProductConstant.CONST_PRODUCT_APP_ROLE_LIST,
      app_devise:ProductConstant.CONST_PRODUCT_DEVISE,
      status_list : ProductConstant.CONST_PRODUCT_ORDERS_STATUS,
      categories_list: ProductConstant.CONST_PLATS_CATEGORIES,  // {code_s: '-1', label:{fr:'TOUT'}}
      bgcolor_list : [],
      icons: [ 'mdi-facebook', 'mdi-twitter', 'mdi-linkedin', 'mdi-instagram'],
      text: {btn_list_p:'Liste des plats', btn_c:'Connexion', btn_o:'Création de compte', btn_ma:' Mon Compte'},

    
      slides:
      [
        { n: 'Charwarma', i: 'assets/imglist/food_pic_1.jpg', id:1},
        { n: 'Affila', i: 'assets/imglist/food_pic_2.jpg', id:2},
        { n: 'Tila de mouton', i: 'assets/imglist/food_pic_3.jpg', id:3},
        { n: 'Filet de Boeuf tadi ', i: 'assets/imglist/food_pic_4.jpg', id:4},
        { n: 'Pain fouree ', i: 'assets/imglist/food_pic_5.jpg', id:5},
      ],
      m_link:{ auth: ProductConstant.CONST_PAGE_URL_LIST.auth.path, m_account: ProductConstant.CONST_PAGE_URL_LIST.myorders.path },

      m_page_caract:{ create: '0', edit: '1',   pid: ''},  // pid: Order ID 
      list :{
        search:'',   
        list_base:[],  
        list_shown:[],
        restau:[],
        index:0,
        all:0,
        selecteditem:'', 
        height : window.screen.height - 100,
        filter_selected: '--',
        filter_list: ProductConstant.CONST_PRODUCT_ORDERS_STATUS_LIST.concat({ v: -1, n: '_TOUT_'})
      },
      cart_article_list: [],
      cart:{order_nb_article:0, order_price:0},
      current_restau_id:"", current_restau_mail:"",current_restau_name:"", 
      showbox:{ article_list :false, confirm_order:false, mobilemenu:false },
      toast:{ on: false, timeout: 5000, msg: '', color:'' },

      overlay:false, absolute: true,
      form:{search:''},
      loading: {list: false, confirm:false, listfield:false },
      is_mobile : false,
    };
  },
  mounted() {
    u_data = ProductGlobalFunct.f_udecryptparse( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
    if(u_data)
    {
        this.app_uPID = u_data.ui;
        this.app_uToken = u_data.utk;
        this.app_uName = u_data.un;
    }

    // Build Random Color For Categories
    var c,d= [];
    for (let i = 0; i < this.categories_list.length; i++) {
      c = ProductGlobalFunct.f_generate_color();
      d.push(c);
    }
    this.bgcolor_list = d;

    this.is_mobile = ProductGlobalFunct.f_isMobile();
    this.f_food_list();
    
  },
   filters:{
    capitalize: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.charAt(0).toUpperCase() + v.slice(1);
    },
    uppercase: function (v) {
      if (!v) return ''
      v = v.toString()
      return v.toUpperCase();
    }
  },
  watch: {
      /** @overlay Watch Overlay Change  @param val : True - False*/
      overlay (val) {  val && setTimeout(() => { this.overlay = false}, 3000)},
  },
  methods: {
    /** ----------------------------- CART SYSTEM ----------------------------- */
    /** @f_add_cart Add to Basket , Cart */
    f_add_cart:function(id, item){
      if(!this.cart_article_list.length)
      {
        this.current_restau_id = item.restau_id;
        this.current_restau_name = item.rname;
        this.current_restau_mail = item.restau_m;
        ProductGlobalFunct.f_set_toast(true,  "Vous avez ajouté un article du restaurant " +  item.rname  + " . Ajoutez d'autres articles ou aller dans votre panier (Bouton au bas droit)" ,5500,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.info, this);
      }
      
      if(this.cart_article_list.length &&  (this.current_restau_id != item.restau_id))
      {
        ProductGlobalFunct.f_set_toast(true,  "Oops, Tous les articles d'une même commande ne peuvent provenir que d'un seul restaurant. Vous pouvez filter les restaurants" ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.info, this);
        return;
      }
      var e = 0;
      if(this.cart_article_list.length)
      {
          this.cart_article_list.map((v, i)=>{
            if(v.plat_id == id)
            {
              this.cart_article_list[i]['nb']+=1;
              this.cart_article_list[i]['price_total_article'] =  this.cart_article_list[i]['nb'] * v.punit
              e = 1;
            }
          });
      }


      // Add data
      if(e == 0)
      {
        var price_u = parseInt(item.price,10);
        var article_item = {
          plat_id : id,
          plat_name : item.name,
          nb : 1,
          punit : price_u,
          price_total_article : price_u * 1
        };
        this.cart_article_list.push(article_item);
        this.cart_article_list_clone = this.cart_article_list;
      }
      
      // Update Total 
      var all_sum = 0;
      this.cart_article_list.map((v)=>{
        all_sum += v.price_total_article;
      });

      this.cart.order_nb_article = this.cart_article_list.length;
      this.cart.order_price =  all_sum;
    },
    /** @f_cart_remove Remove From List @param id Plat ID  */
    f_cart_remove:function(id){
      let d = this.cart_article_list.filter((v)=> v.plat_id != id);
      this.cart_article_list = d;
      if(!this.cart_article_list.length) 
      { 
        this.showbox.article_list = false; 
        this.current_restau_id = this.current_restau_name = this.current_restau_mail = ""; // Reset data
        return;
      }

      // Update Total 
      var all_sum = 0;
      this.cart_article_list.map((v)=>{
        all_sum += v.price_total_article;
      });

      this.cart.order_nb_article = this.cart_article_list.length;
      this.cart.order_price =  all_sum;
    },
    /** @f_cart_updateq Update a quantity on Cart  @param id Plat ID  @param evt event */
    f_cart_updateq:function(id, evt){
      var v = evt.target.value;
      if(!v) { return;}

      // 1 - Update El 
      try {
        v = parseInt(v, 10);
      } catch (error) {
        ProductGlobalFunct.f_set_toast(true, "Ooops, erreur" ,2000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }

      var x;
      for (let i = 0; i < this.cart_article_list.length; i++) {
        x = this.cart_article_list[i];
        if(x.plat_id == id)
        {
          this.cart_article_list[i]['nb'] = v;
          this.cart_article_list[i]['price_total_article'] = v * x.punit;
          break;
        }
      }

      // 2 - Update Total 
      var all_sum = 0;
      this.cart_article_list.map((v)=>{
        all_sum += v.price_total_article;
      });

      this.cart.order_nb_article = this.cart_article_list.length;
      this.cart.order_price =  all_sum;
    },
    /** @f_cart_check Check cart  */
    f_cart_check:function(){
      if(!this.cart_article_list.length)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, erreur imprevue (R:F1610211437)" ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }

      var x = 0, e = 0;
      if(!this.cart.order_nb_article || !this.cart.order_price )
      { 
        return 1;
      }
     
      for (let i = 0; i < this.cart_article_list.length; i++) {
        x = this.cart_article_list [i];
        if(!x.nb  ||  x.nb<0) 
        {
          e = 1;
          break;
        }
      }
      return e;
    },

    /** @f_make_order Make Order */
    f_make_order: function(){
      // Checking  data  ...
      if(!this.app_uPID)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Vous devez être connecté  ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      var cart_check_result = this.f_cart_check();
      if(cart_check_result == 1)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Une (ou plusieurs erreurs) au niveau du panier   ", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
    
      var d = Date.now();

      this.loading.save = true;
      s = {
        ui: this.app_uPID, 

        on : 'Cmd ' + ( Math.random().toString().slice(2, 6) ) + (Date.now())  + ' - ' + this.cart.order_nb_article  + ' articles',
        rr:  this.current_restau_id,
        rc:  this.app_uPID,
        os: ProductConstant.CONST_PRODUCT_ORDERS_STATUS.NON_VALIDE,
        ona: this.cart.order_nb_article,
        opt:  this.cart.order_price,
        al: this.cart_article_list ,
        od: d,

        re : this.current_restau_mail,
        rn: this.current_restau_name,
        md: ProductGlobalFunct.f_date_toappdateformat(d),
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
        _pvtk: this.app_uToken,
        _ui: this.app_uPID
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.order_set , s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.save = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          this.loading.save = false;
          ProductGlobalFunct.f_set_toast(true, " ✔ Bien, Commande effectuée. Vous recevrez une notification de validation par le Restaurant. Votre commande est visible dans votre compte" ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
          setTimeout(() => {
            this.cart_article_list = [];
            this.showbox.article_list = false;
          }, 1000);
        },
        (error) =>{
          this.loading.save = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },
   
   /** ----------------------------- FOOD LIST  ----------------------------- */
    
    /** @f_food_list Get list of Foods      TODO:LATER Get Partially Not all   */
    f_food_list:function(){
      this.loading.list = true;
      s = {
        pn: ProductConstant.CONST_PRODUCT_NAME,

        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME,
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.foods_list, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.list = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + ' ' +  data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          // Success
          this.list.restau = [{id:-1,rn: 'TOUT'}].concat( data.restau_list) ; 
          this.list.list_base = data.payload; 
          this.list.list_shown = data.payload; 
          
          this.loading.list = false;
        },
        (error) =>{
          this.loading.list = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },


    /** ----------------------------- UTILITY FUNC  ----------------------------- */
    /** @f_search Search In List   */
    f_search:function(o, evt){
      var v;
      switch (o) {
        case 1:  // Search In Foods List 
          v = evt.target.value;
          this.list.filter_selected = "";
          if(!v) { this.list.list_shown = this.list.list_base; return; }
          this.list.list_shown =  this.list.list_base.filter ((x)=> x.name.toLowerCase().indexOf( (v).toString().toLowerCase() ) != -1 );
          break;
      
        default:break;
      }

    },
    /** @f_filter Filter the list @param o Option @param v Filter By  TODO:   */
    f_filter:function(o, v){
      switch (o) {
        case 1:  // Filter The list By  Categories
            this.f_goto_local(1,'.pl_list');
            if(v == -1){ this.list.list_shown = this.list.list_base;  this.list.filter_selected = v; return;  }
            this.list.list_shown =  this.list.list_base.filter ((x)=> x.pcat == v );
            this.list.filter_selected = v;
            break;

        case 2:  // Filter The list By  Restaurant name 
            this.f_goto_local(1,'.pl_list');
            if(v == -1){ this.list.list_shown = this.list.list_base; return;  }
            this.list.list_shown =  this.list.list_base.filter ((x)=> x.restau_id == v );
            break;
      
        default:break;
      }

    },

    /** @f_switcher Switch ...  */
    f_switcher:function(o){
      this.showbox.section = o;
    },
    /** @f_goto_local Goto  @param o Option @param e Element @param p? Url */
    f_goto_local:function(o, e, p=''){
      switch (o) {
        case 1: // Goto
          var d = document.querySelector(e);
          d.scrollIntoView({behavior:'smooth'});
          break;
        case 2: // Goto
          ProductGlobalFunct.f_goto(1, p, this);
          break;
      
        default:
          break;
      }
      

    },
    /** @f_showbox ShowBox @param Option @param v Value   */
    f_showbox:function(o, v = null){
      switch (o) {
        case 1: this.showbox[v] = !this.showbox[v]; break;
        default:break;
      }
    },
  }

}
</script>
