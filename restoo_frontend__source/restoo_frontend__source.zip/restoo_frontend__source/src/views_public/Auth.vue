<!-- ============================================================+
// File name   : Auth.vue
// Begin       : 06.10.21
// Last Update : 06.10.21
//  
// Description : Authentification Page : Handle (Account Creation + Sign +  PassReset )
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                 Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 


<!-- ----------------------- T E M P L A T E : DOM  ----------------------- -->

<template>
  <v-app>
    <v-main class="grey lighten-4 d_flex aic jcc" >

      <v-container  align-self="center" >
        <!-- CREATION DE COMPTE  : FORM INIT  -->
        <v-row align-self="center"  class="animate__animated  animate__slideInRight"  v-if="operation.current == operation._signup" >
          <v-col xl="3"  lg="3" md="3" sm="2" xs="1" ></v-col>
          <v-col xl="6" lg="6" md="6" sm="8" xs="10" >
             <v-card elevation="3" class="pa-4 grey lighten-5" color="transparent"  >
                <h2 class="text-center fw_light" > Création de compte  </h2>

                <div class="mt-2 mb-3" >
                  <v-form>
                    <!-- NOM PRENOMS  --><!--  -->
                    <v-text-field type="text"  placeholder="..."  label="Votre nom et prenom" v-model="signup_model.uname" ></v-text-field>
                    
                    <!-- EMAIL 1-->
                    <v-text-field type="email"  placeholder="..."  label="Votre email" v-model="signup_model.uemail_1"  class="mt-2" ></v-text-field>
                    <!-- EMAIL 2-->
                    <v-text-field type="email"  placeholder="..."  label="Votre email (Répétez)" v-model="signup_model.uemail_2"  class="mt-2" ></v-text-field>

                  </v-form>

                  <!-- SAVE BTN -->
                  <div class="w-100 mt-2 d_flex aic jcc">
                      <v-btn large elevation="2" color="primary" align-self="center"  :loading="loading.signup"  @click="f_sign_up()"> Créer mon compte  </v-btn>
                  </div>

                  <!-- NO, ACCOUNT, GO CREATE ACCOUNT   -->
                  <br><br>
                  <div class="w-100 mt-5" > <v-chip align="start" @click="f_switcher(operation._signin)"  >   Déja un compte? Se connecter  </v-chip>  </div>

                </div>
              </v-card>
          </v-col>
          <v-col xl="3"  lg="3" md="3" sm="2" xs="1" ></v-col>
        </v-row>

        <!-- CREATION DE COMPTE : CONFIRMATION DE COMPTE   -->
        <v-row align-self="center" class="animate__animated  animate__slideInRight" v-if="operation.current == operation._signup_code" >
          <v-col xl="4" lg="4" md="4" sm="2" xs="1" ></v-col>
          <v-col xl="4" lg="4" md="4" sm="8" xs="10" >
            <v-card elevation="2" class="pa-4 grey lighten-5" >
              <h2 class="text-center fw_light" > Confirmation de compte   </h2>

              <div class="mt-2 mb-3" >
                  <v-form>
                    <v-text-field type="text"  placeholder="..."  label="Le code qui vous été envoyé " v-model="signup_model.code_sent" ></v-text-field>
                  </v-form>

                  <!-- SAVE BTN -->
                  <div class="w-100 mt-2 d_flex aic jcc">
                      <v-btn large elevation="2" color="primary" align-self="center"  :loading="loading.signup_validecodesent" @click="f_confirm_code(validecode_option.SIGNUP_VALIDE)" > Confirmer  </v-btn>
                  </div>
              </div>
            </v-card>
          </v-col>
           <v-col xl="4" lg="4" md="4" sm="2" xs="1" ></v-col>
        </v-row>

        <!-- LOGIN   -->
        <v-row align-self="center" class="animate__animated  animate__slideInLeft" v-if="operation.current == operation._signin" >
          <v-col xl="4" lg="4" md="4" sm="2" xs="1" ></v-col>
          <v-col xl="4" lg="4" md="4" sm="8" xs="10" >
            <v-card elevation="2" class="pa-4 grey lighten-5" >
              <h2 class="text-center fw_light" > Connexion à votre compte    </h2>

              <div class="mt-2 mb-3" >
                <v-form>
                  <!-- EMAIL -->
                  <div v-if="operation_login.current == operation_login._email" >
                    <v-text-field type="text"  placeholder="..."  label="Email" v-model="signin_model.uemail" ></v-text-field>
                  </div>

                  <!-- PASS -->
                  <div v-if="operation_login.current == operation_login._password"  class="animate__animated  animate__slideInRight" >
                    <v-text-field type="password"  placeholder="..."  label="Mot de passe" v-model="signin_model.upass" ></v-text-field>

                    <div class="d_flex jcfe" >  <v-chip align="end" @click="f_switcher(operation._passreset)" > Mot de passe oublié ?   </v-chip>  </div>
                  </div>

                </v-form>

                <!-- SAVE BTN -->
                <div class="w-100 mt-2 d_flex aic jcc">
                    <v-btn large elevation="2" color="primary"  :loading="loading.signin"  @click="f_sign_in()"> Suivant  </v-btn>
                </div>

                <!-- NO, ACCOUNT, GO CREATE ACCOUNT   -->
                <br><br>
                <div class="w-100 mt-5 " > <v-chip  align="start"  @click="f_switcher(operation._signup)" > Pas de compte? Créer un compte  </v-chip>  </div>
              </div>
            </v-card>
          </v-col>
           <v-col xl="4" lg="4" md="4" sm="2" xs="1" ></v-col>
        </v-row>

        <!-- RESET PASS   -->
        <v-row align-self="center" class="animate__animated  animate__slideInRight" v-if="operation.current == operation._passreset" >
          <v-col xl="3"  lg="3" md="3" sm="2" xs="1" ></v-col>
          <v-col xl="6"  lg="6" md="6" sm="8" xs="10" >
            <v-card elevation="2" class="pa-4 grey lighten-5" >
           
              <h2 class="text-center fw_light" > Réinitialisation de votre mot de passe     </h2>

              <div class="mt-2 mb-3">
                <v-form>
                  <!-- EMAIL -->
                  <div v-if="operation_reset.current == operation_reset._email" >
                    <v-text-field type="text"  placeholder="..."  label="Email" v-model="passreset_model.uemail" ></v-text-field>
                  </div>

                  <!-- CONFIRM CODE SENT BY EMAIL -->
                  <div v-if="operation_reset.current == operation_reset._code"  class="animate__animated  animate__slideInRight" >
                    <v-text-field type="password"  placeholder="..."  label="Le code qui vous a été envoyé" v-model="passreset_model.ucode" ></v-text-field>
                  </div>

                </v-form>

                <!-- SAVE BTN -->
                <div class="w-100 mt-2 d_flex aic jcc ">
                    <v-btn large elevation="2" color="primary" align-self="center"  :loading="loading.passreset" @click="f_pass_reset_init()" >  Suivant  </v-btn>
                </div>

                <!-- NO RETURN TO LAST   -->
                 <br><br>
                <div class="w-100 mt-5" > <v-chip align="start"  @click="f_switcher()" > Retour </v-chip>  </div>
              </div>
            </v-card>
          </v-col>
          <v-col xl="3"  lg="3" md="3" sm="2" xs="1" ></v-col>
        </v-row>

        <!-- SNACKBAR :PROCESS -->
        <v-snackbar v-model="toast.on" :timeout="toast.timeout" :color="toast.color" >
          {{toast.msg}}

          <template v-slot:action="{ attrs }">
            <v-btn class="white--text rounded-circle" color="transparent"  v-bind="attrs" @click="toast.on = false"> X </v-btn>
          </template>

        </v-snackbar>
      </v-container>
        
    </v-main>
  </v-app>
</template>


<!-- ----------------------- S T Y L E ----------------------- -->
<style scoped>
  .v-card{ min-height:340px !important ; }
</style>


<!-- ----------------------- S C R I P T  ----------------------- -->
<script>
// ----------- REQUIRE NECESSARIES MODULES -----------
import ProductConstant from '../config/ProductConstant';
import ProductGlobalFunct from '../config/ProductGlobalFunct';
import AccountService from '../services/AccountService'

// ----------- SOME GLOBAL VAR  -----------
var s = {};

export default {
  name: 'Auth',
  data() {
    return {
      signup_model:{ uemail_1:'', uemail_2:'',  code_sent: '', uname:''},
      signin_model:{ uemail:'', upass: ''},
      passreset_model:{ uemail:'', ucode: ''},
      loading:{ signup:false, signup_validecodesent:false,   signin:false, passreset:false },
      showbow:{},
      operation:{current: 1, last: 0,  _signup:1,_signup_code:11,_signin:2,_passreset:3 },
      operation_login:{current: 1,_email:1,_password:2},
      operation_reset:{current: 1,_email:1,_code:2},
      toast:{ on: false, timeout: 5000, msg: '', color:'' },
      validecode_option: ProductConstant.CONST_PRODUCT_VALIDECODE_OPTION
    };
  },
  mounted() {
    // Get Params If Exist : Switch to session
    // var p = this.$route.params.o;
  },
  methods: {
    /** @f_sign_up  User Sign Up: [ Check data,   Save data & Send (code + password) by email to confirm   ] */
    f_sign_up:function(){
      // Checking  data  ...
      var 
          umail1  = this.signup_model.uemail_1,
          umail2  = this.signup_model.uemail_2,
          uname  = this.signup_model.uname;

      if(!umail1 ||  !umail2 || !uname)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, champs vides", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      
      if(umail1 != umail2)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, mails non identiques", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }
      if( !ProductConstant.CONST_EMAIL_FORMAT.test( umail1))
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Le format de l'email semble être incorrect", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        return;
      }

      // Send to BE  
      this.loading.signup = true;
      s = {
        ue: umail1, 
        un: uname,
      
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.sign_up, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error
          {
            this.loading.signup = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          if(data.isOkay == -1)   // Case : Mail Busy
          {
            this.loading.signup = false;
            ProductGlobalFunct.f_set_toast(true, "Ooops, utilisateur existant" ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.info, this);
            return;
          }

          // Success
          this.loading.signup = false;
          ProductGlobalFunct.f_set_toast(true, "Cool 👍  Un mail vous a été envoyé.[Regardez aussi les spams]" ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);

          setTimeout(() => {
            this.f_switcher(this.operation._signup_code);
          }, 1500);
        },
        (error) =>{
          this.loading.signup = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },
    /** @f_confirm_code  Confirm Code  (SignUp Code  + PassReset ) :: Confirm Code sent by email : [ SignUp:: Check data,   if match go account   ] @param o Option  */
    f_confirm_code:function(o){
      // Checking  data  ...
      var code_sent, uid;

      if(o == ProductConstant.CONST_PRODUCT_VALIDECODE_OPTION.SIGNUP_VALIDE)
      {
        code_sent  = this.signup_model.code_sent;
        uid = this.signup_model.uemail_1;
        this.loading.signup_validecodesent = true;
      }

      if(o == ProductConstant.CONST_PRODUCT_VALIDECODE_OPTION.PASSRESET_VALIDE)
      {
        code_sent  = this.passreset_model.ucode;
        uid = this.passreset_model.uemail;
        this.loading.passreset = true;
      }

      if(!code_sent)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, champ vide", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        this.loading.signup_validecodesent = false;
        this.loading.passreset = false;
        return;
      }
      if(!uid)
      {
        ProductGlobalFunct.f_set_toast(true, "Ooops, Erreur imprevue", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        this.loading.signup_validecodesent = false;
        this.loading.passreset = false;
        return;
      }

      // Send to BE  
      s = {
        ui: uid, uc: code_sent, o: o,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.valide_code, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case : Error (TODO:LATER : Count Fail Error )
          {
            this.loading.signup_validecodesent = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          // Success
          if( data.o == ProductConstant.CONST_PRODUCT_VALIDECODE_OPTION.SIGNUP_VALIDE)
          {
            ProductGlobalFunct.f_set_toast(true, "Bien. Code Correct, Connexion ..." ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
            this.loading.signup_validecodesent = false;

            setTimeout(() => {
              this.operation_login.current = this.operation_login._email;
              this.f_switcher(this.operation._signin);
            }, 1500);
          }

          if(o == ProductConstant.CONST_PRODUCT_VALIDECODE_OPTION.PASSRESET_VALIDE)
          {
            // Save data + Redirect to User Private data page 
            ProductGlobalFunct.f_set_toast(true, "Bien. Code Correct, Redirection Pour Changement de Mot de passe ... " ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
            this.loading.passreset = false;
            localStorage.setItem( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT, data.ciphertext);
            localStorage.setItem(ProductConstant.CONST_PRODUCT_STORAGE_T_SET, data.ds);
            setTimeout(() => {
              ProductGlobalFunct.f_goto(1, ProductConstant.CONST_PAGE_URL_LIST.mydata.path, this);
            }, 1500);

          }
        },
        (error) =>{
          this.loading.signup_validecodesent = false;
          this.loading.passreset = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });

    },
    /** @f_sign_in  User Sign In: [ Check data && logged in ] (Step 1 + Step 2)  */
    f_sign_in:function(){
      var 
          umail  = this.signin_model.uemail.trim(),
          upass  = this.signin_model.upass;

      if( this.operation_login.current == this.operation_login._email )
      {
        if(!umail)
        {
          ProductGlobalFunct.f_set_toast(true, "Ooops, champs vide", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
          return;
        }
      }

      if( this.operation_login.current == this.operation_login._password )
      {
        if(!upass)
        {
          ProductGlobalFunct.f_set_toast(true, "Ooops, champs vide", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
          return;
        }
      }

      // Send to BE  
      this.loading.signin = true;
      s = {
        ue: umail,  up: upass,  o : this.operation_login.current,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.sign_in, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case 
          {
            this.loading.signin = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }

          if(data.isOkay == -1)   // Case : TODO:LATER Count Error
          {
            this.loading.signin = false;
            ProductGlobalFunct.f_set_toast(true, "Ooops, Coordonnées non correctes " ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
          
          // Success
          this.loading.signin = false;
          if( data.o == this.operation_login._email )
          {
            this.operation_login.current = this.operation_login._password;
            return;
          }

          if( data.o == this.operation_login._password )
          {
            // Save U data 
            localStorage.setItem( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT, data.ciphertext);
            localStorage.setItem(ProductConstant.CONST_PRODUCT_STORAGE_T_SET, data.ds);

            if(data.setup == 0)  // Go Set Account 
            {
              ProductGlobalFunct.f_goto(1, ProductConstant.CONST_PAGE_URL_LIST.setup.path, this);
              return;
            }
            if(data.setup == 1)  // Go User Account 
            {
              var account_url = ProductConstant.CONST_PAGE_URL_LIST.myorders.path;
              ProductGlobalFunct.f_goto(1, account_url, this);
              return;
            }
          }
        },
        (error) =>{
          this.loading.signup = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });
    },
    /** @f_pass_reset_init  Step1: Send Mail To User  | Step2: f_confirm_code  TODO:SET   */
    f_pass_reset_init:function(){
      var 
          umail  = this.passreset_model.uemail.trim();

      if( this.operation_reset.current == this.operation_reset._email )
      {
        if(!umail)
        {
          ProductGlobalFunct.f_set_toast(true, "Ooops, champs vide", 4000, ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
          return;
        }
      }

      if( this.operation_reset.current == this.operation_reset._code )
      {
        this.f_confirm_code(ProductConstant.CONST_PRODUCT_VALIDECODE_OPTION.PASSRESET_VALIDE);
        return;
      }

      // Send to BE  
      this.loading.passreset = true;
      s = {
        ue: umail,
      
        _ptk: ProductConstant.CONST_PRODUCT_PUBLIC_TOKEN,
        _pn: ProductConstant.CONST_PRODUCT_NAME
      };
      AccountService.fs_restoo_post(ProductConstant.CONST_BACKEND_ENDPOINT_LIST.passreset_init, s)
        .then((data) =>{
          if(data.isOkay == 0)    // Case 
          {
            this.loading.passreset = false;
            ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_IMPREVUE.fr + data.err_code ,4000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
            return;
          }
          
          // Success
          this.loading.passreset = false;
          ProductGlobalFunct.f_set_toast(true, "Bien. Un mail vous a été envoyé si cela existe dans notre système [Regardez aussi les spams]" ,5000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.success, this);
          if(data.isOkay == 1)
          {
            this.operation_reset.current = this.operation_reset._code;
          }
          return;
        },
        (error) =>{
          this.loading.passreset = false;
          ProductGlobalFunct.f_set_toast(true, ProductConstant.CONST_PRODUCT_ERROR_DATANOTSENT.fr + ':: ' +  error ,6000,  ProductConstant.CONST_BASE_SNACBAR_NOTIF_STYLE.error, this);
        });

    },
    
    /** @f_switcher Switch between section of Auth Page : operation type  @param o Operation    */
    f_switcher:function(o=null){
      if(o)
      {
        this.operation.current = o;
        if(o != this.operation._passreset)
        {
          this.operation.last = o;
        }

        if( o ==  this.operation._passreset)  // Prefill PassResetEmail Field 
        {
          this.passreset_model.uemail = this.signin_model.uemail;
        }
      } else {
        this.operation.current  = this.operation.last;
      }
    },
  
  },
}
</script>



