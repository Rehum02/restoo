// <!-- ============================================================+
// File name   : AccountGuard.js
// Begin       : 07.10.21
// Last Update : 07.10.21
//  
// Description : Guard Before Enter Account Route
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                      Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

// ---------------- GET FILES  ----------------
import ProductConstant from "../config/ProductConstant";
import ProductGlobalFunct from '../config/ProductGlobalFunct';


// ---------------- SOME VAR   ----------------
var 
    app_uPID = "",
    app_uToken = "",
    app_uType = "",
    app_Ds = "";

export default {
    
    /** @f_check_auth Check User Is Authentificated @param to Next Path @param from From Route  @param next Go next */
    f_check_auth: function(to, from, next){
        var ciphertext= localStorage.getItem( ProductConstant.CONST_PRODUCT_STORAGE_EM_PRODUCT);
        var _st = localStorage.getItem( ProductConstant.CONST_PRODUCT_STORAGE_T_SET);
        if(!ciphertext)
        {
            next(ProductConstant.CONST_PAGE_URL_LIST.phome.path );
            return;
        }

        var plain = ProductGlobalFunct.f_aes_decrypt(ciphertext, 'PLAINTEXT'),
            u_data;
        if(plain)
        {
            try {u_data=JSON.parse(plain);} 
            catch (error) { 
                next(ProductConstant.CONST_PAGE_URL_LIST.phome.path );
                return;
            }

            app_uPID = u_data.ui;
            app_uToken = u_data.utk;
            app_uType = u_data.ut;
            app_Ds = u_data._st;
        }
        if(!app_uPID || !app_uToken ||  (_st != app_Ds))
        {
          next(ProductConstant.CONST_PAGE_URL_LIST.phome.path );
          return;
        } 

        let prop = to.path .split('/')[2]; 
        var exclude_path = 
        [
            ProductConstant.CONST_PAGE_URL_LIST.setup.name
        ];
        if( exclude_path.includes(prop)){ next(); return;}

        if( ProductConstant.CONST_PAGE_URL_LIST[prop].role.indexOf( app_uType ) == -1 )
        {
            next(ProductConstant.CONST_PAGE_URL_LIST.phome.path );
            return;
        } 
        return  next() ;
    },
};