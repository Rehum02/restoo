import Vue from 'vue';
import Vuetify from 'vuetify/lib/framework';
import colors from 'vuetify/lib/util/colors'

Vue.use(Vuetify);

export default new Vuetify({
    theme: {
        themes: {
            light: {
              primary: colors.amber.base,
              secondary: colors.shades.black,  //  colors.brown.base, 
              accent: colors.shades.white
            },
          },
    },
});
