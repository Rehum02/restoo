// <!-- ============================================================+
// File name   : AccountService.js
// Begin       : 06.10.21
// Last Update : 06.10.21
//  
// Description : Service when logged In 
//  
// Project     :  Restoo  
// Designed By :  Miché KOKORA 
// For         :  GS2E
//  
// Contributors  :
//                      Miché KOKORA 
// 
// (c) Copyright 2021
// ============================================================+ --> 

// ---------------- GET FILES  ----------------
import ProductConstant from "../config/ProductConstant";
import axios from 'axios';


export default {
    /** @fs_restoo_post Post data to Server @param path Path @param data @ params  */
    fs_restoo_post: async function (path, data){
        let p = ProductConstant.CONST_BACKEND_ROOT_PATH + '' + path;
        let res = await axios.post(p, JSON.stringify(data), {headers:{'Content-Type':'application/json;charset=UTF-8'}} );
        return res.data;
    },

    /** @fs_restoo_post Get  data from  Server @param path Full Path */
    fs_restoo_get: async function (path){
        let p = ProductConstant.CONST_BACKEND_ROOT_PATH + '' + path;
        let res = await axios.get(p, {headers:{'Content-Type':'application/json;charset=UTF-8'}} );
        return res.data;
    }
};