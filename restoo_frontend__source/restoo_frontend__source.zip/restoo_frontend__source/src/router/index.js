
import Vue from 'vue'
import VueRouter from 'vue-router'
import AccountGuard from '../guards/AccountGuard';
import Account from '../views_protected/Account' 

Vue.use(VueRouter)

const routes = [
  {path: '/', name: 'Phome', component: () => import('../views_public/Phome.vue')},
  {path: '/auth/:o?', name: 'Auth', component: () => import('../views_public/Auth.vue')},

  // ------------------- LOGGED IN -------------------------------------------
  {path: '/u/setup', name: 'Setup', component: () => import('../views_protected/Setup.vue'), beforeEnter: function(to, from, next){AccountGuard.f_check_auth(to, from, next);}},

  {
    path:'/account', 
    component : Account,    
    children:
    [
      {path: 'myorders', name: 'Myorders', component: () => import('../views_protected/Myorders.vue'), beforeEnter: function(to, from, next){AccountGuard.f_check_auth(to, from, next);}},
      
      {path: 'rmyfoods', name: 'Rmyfoods', component: () => import('../views_protected/Rmyfoods.vue'), beforeEnter: function(to, from, next){AccountGuard.f_check_auth(to, from, next);}},
      {path: 'rmybalance', name: 'Rmybalance', component: () => import('../views_protected/Rmybalance.vue'), beforeEnter: function(to, from, next){AccountGuard.f_check_auth(to, from, next);}},
      {path: 'mydata', name: 'MyData', component: () => import('../views_protected/MyData.vue'), beforeEnter: function(to, from, next){AccountGuard.f_check_auth(to, from, next);}},
    ]
  },

  {path: '**',  redirect:'/'},
 
  // TODO:SET  When no route
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
